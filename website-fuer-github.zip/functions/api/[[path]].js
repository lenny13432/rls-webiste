// =====================================================================
//  Real Life Southland – API für Team-Bewerbungen
//  Läuft als Cloudflare Pages Function, Daten liegen in D1 (Binding "DB").
//
//  Umgebungsvariablen (Cloudflare → Pages-Projekt → Einstellungen → Variablen):
//    SETUP_KEY          Geheimes Wort für die Ersteinrichtung (Pflicht)
//    DISCORD_WEBHOOK    Webhook-URL für Benachrichtigungen im Team-Kanal (optional)
//    SITE_URL           z. B. https://southland-rp.de (optional, für Links in Discord)
//    COOLDOWN_DAYS      Wartezeit nach Ablehnung in Tagen (Standard 7)
//    DELETE_AFTER_DAYS  Entschiedene Bewerbungen nach X Tagen löschen (Standard 90, 0 = nie)
//    MIN_AGE            Mindestalter (Standard 16)
// =====================================================================

const SESSION_COOKIE = 'rls_session';
const SESSION_HOURS = 12;
const STATUSES = ['offen', 'pruefung', 'angenommen', 'abgelehnt'];
const LABEL = { offen: 'Offen', pruefung: 'In Prüfung', angenommen: 'Angenommen', abgelehnt: 'Abgelehnt' };
const HOURS = ['unter 5 Stunden', '5–10 Stunden', '10–20 Stunden', 'über 20 Stunden'];

// ---------------------------------------------------------------- Helfer
const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers } });
const fail = (message, status = 400) => json({ error: message }, status);
class HttpError extends Error { constructor(msg, status = 400) { super(msg); this.status = status; } }

const now = () => new Date().toISOString();
const isoAgo = (ms) => new Date(Date.now() - ms).toISOString();
const len = (s) => [...String(s ?? '')].length;
const str = (v, max = 10000) => String(v ?? '').trim().slice(0, max);
const intEnv = (env, k, d) => { const n = parseInt(env[k], 10); return Number.isFinite(n) ? n : d; };

const enc = new TextEncoder();
const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
async function sha256(text) {
  const d = await crypto.subtle.digest('SHA-256', enc.encode(text));
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

// Passwörter: PBKDF2-SHA256, 100.000 Runden (Maximum in Cloudflare Workers)
async function hashPassword(pw, salt = crypto.getRandomValues(new Uint8Array(16)), iter = 100000) {
  const key = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, key, 256);
  return `pbkdf2$${iter}$${b64(salt)}$${b64(bits)}`;
}
async function verifyPassword(pw, stored) {
  const [kind, iter, salt, hash] = String(stored).split('$');
  if (kind !== 'pbkdf2') return false;
  const again = await hashPassword(pw, unb64(salt), parseInt(iter, 10));
  return safeEqual(again.split('$')[3], hash);
}
function randomString(len, alphabet) {
  const bytes = crypto.getRandomValues(new Uint8Array(len));
  return [...bytes].map((b) => alphabet[b % alphabet.length]).join('');
}
const newCode = () => { const r = randomString(8, 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'); return r.slice(0, 4) + '-' + r.slice(4); };
const newPassword = () => randomString(14, 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789');

const clientIp = (req) => req.headers.get('CF-Connecting-IP') || req.headers.get('X-Forwarded-For') || '0.0.0.0';
const ipHash = (req, env) => sha256(clientIp(req) + '|' + (env.SETUP_KEY || 'rls'));

async function readBody(req) {
  const text = await req.text();
  if (text.length > 60000) throw new HttpError('Die Anfrage ist zu groß.', 413);
  try { return text ? JSON.parse(text) : {}; } catch { throw new HttpError('Ungültige Anfrage.'); }
}

function cookie(req, name) {
  const m = (req.headers.get('Cookie') || '').match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)'));
  return m ? decodeURIComponent(m[1]) : null;
}
function sessionCookie(req, value, maxAge) {
  const secure = new URL(req.url).protocol === 'https:' ? '; Secure' : '';
  return `${SESSION_COOKIE}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure}`;
}

async function getSettings(db) {
  const rows = (await db.prepare('SELECT key, value FROM settings').all()).results || [];
  const s = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  let positions = [];
  try { positions = JSON.parse(s.positions || '[]'); } catch {}
  return { open: s.applications_open !== 'false', positions };
}

async function discordNotify(env, ctx, embed) {
  if (!env.DISCORD_WEBHOOK) return;
  const body = JSON.stringify({ username: 'Southland Team-Bewerbungen', embeds: [{ timestamp: now(), footer: { text: 'Real Life Southland' }, ...embed }] });
  const p = fetch(env.DISCORD_WEBHOOK, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body }).catch(() => {});
  if (ctx && typeof ctx.waitUntil === 'function') ctx.waitUntil(p); else await p;
}
// Eigene Discord-Kanäle pro Thema: Webhook-Links liegen in der Datenbank (Panel → Einstellungen), nie im Code
const WEBHOOK_RE = /^https:\/\/(?:(?:canary|ptb)\.)?discord(?:app)?\.com\/api\/webhooks\/\d{5,25}\/[\w-]{20,100}$/;
const WEBHOOK_KINDS = { rules: 'Regelwerk-Ankündigungen' };
async function getWebhook(env, kind) {
  const row = await env.DB.prepare('SELECT value FROM settings WHERE key = ?').bind('webhook_' + kind).first();
  return (row && row.value) || env['DISCORD_WEBHOOK_' + kind.toUpperCase()] || env.DISCORD_WEBHOOK || '';
}
async function sendWebhook(url, payload) {
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    return r.ok ? { ok: true } : { ok: false, error: r.status === 404 ? 'Discord kennt diesen Webhook nicht (gelöscht?).' : `Discord hat mit Fehler ${r.status} geantwortet.` };
  } catch { return { ok: false, error: 'Discord war nicht erreichbar.' }; }
}
const maskWebhook = (u) => { const m = String(u || '').match(/webhooks\/(\d+)\//); return m ? `…/webhooks/${m[1].slice(0, 4)}…${m[1].slice(-3)}/••••••` : ''; };
const siteLink = (env, path) => (env.SITE_URL ? env.SITE_URL.replace(/\/$/, '') + path : undefined);

// ---------------------------------------------------------------- Anmeldung
async function currentAdmin(req, env) {
  const token = cookie(req, SESSION_COOKIE);
  if (!token) return null;
  const row = await env.DB.prepare(
    `SELECT a.id, a.name, a.role FROM sessions s JOIN admins a ON a.id = s.admin_id
     WHERE s.token_hash = ? AND s.expires_at > ? AND a.active = 1`
  ).bind(await sha256(token), now()).first();
  return row || null;
}
async function requireAdmin(req, env, ownerOnly = false) {
  await ensureSchema(env.DB);
  const me = await currentAdmin(req, env);
  if (!me) throw new HttpError('Bitte melde dich an.', 401);
  if (ownerOnly && me.role !== 'owner') throw new HttpError('Das darf nur der Projektinhaber.', 403);
  return me;
}

// ---------------------------------------------------------------- Öffentliche Endpunkte
async function getConfig({ env }) {
  const s = await getSettings(env.DB);
  return json({ open: s.open, positions: s.positions, minAge: intEnv(env, 'MIN_AGE', 16), cooldownDays: intEnv(env, 'COOLDOWN_DAYS', 7), deleteAfterDays: intEnv(env, 'DELETE_AFTER_DAYS', 90) });
}

async function postApply({ request, env, ctx }) {
  const db = env.DB;
  const b = await readBody(request);
  const settings = await getSettings(db);
  const minAge = intEnv(env, 'MIN_AGE', 16);
  if (!settings.open) throw new HttpError('Die Bewerbungsphase ist gerade pausiert.', 403);

  const d = {
    discord_name: str(b.discord_name, 40), discord_id: str(b.discord_id, 30).replace(/\D/g, ''),
    age: parseInt(b.age, 10), position: str(b.position, 40), hours: str(b.hours, 40), times: str(b.times, 200),
    experience: str(b.experience, 3000), motivation: str(b.motivation, 3000), scenario1: str(b.scenario1, 2000), scenario2: str(b.scenario2, 2000)
  };
  const errors = [];
  const pos = settings.positions.find((p) => p.name === d.position);
  if (!/^[\p{L}\p{N}_.]{2,32}$/u.test(d.discord_name)) errors.push('Bitte gib deinen Discord-Benutzernamen an (2–32 Zeichen, ohne Leerzeichen).');
  if (d.discord_id && !/^\d{17,20}$/.test(d.discord_id)) errors.push('Die Discord-ID besteht aus 17–20 Ziffern. Lass das Feld leer, wenn du sie nicht findest.');
  if (!(d.age >= minAge && d.age <= 99)) errors.push(`Fürs Team musst du mindestens ${minAge} Jahre alt sein.`);
  if (!pos) errors.push('Bitte wähl aus, in welchem Bereich du helfen möchtest.');
  else if (pos.state === 'voll' || pos.state === 'geschlossen') errors.push(`Im Bereich ${pos.name} suchen wir gerade niemanden.`);
  if (!HOURS.includes(d.hours)) errors.push('Bitte gib an, wie viel Zeit du pro Woche hast.');
  if (len(d.times) < 3) errors.push('Bitte sag uns, wann du meistens da bist.');
  if (len(d.experience) < 30) errors.push('Erzähl uns etwas mehr über deine Team-Erfahrung (mindestens 30 Zeichen).');
  if (len(d.motivation) < 150) errors.push('Erzähl uns etwas mehr, warum wir dich nehmen sollten (mindestens 150 Zeichen).');
  if (len(d.scenario1) < 80 || len(d.scenario2) < 80) errors.push('Beantworte bitte beide Praxisfragen ausführlicher (je mindestens 80 Zeichen).');
  if (!b.rules) errors.push('Bitte bestätige, dass du das Regelwerk kennst.');
  if (!b.volunteer) errors.push('Bitte bestätige, dass dir klar ist, dass die Teamarbeit freiwillig ist.');
  if (!b.privacy) errors.push('Bitte stimme der Speicherung deiner Angaben zu.');
  if (errors.length) return json({ errors }, 422);

  // Spam-Schutz: verstecktes Feld ausgefüllt oder Formular in unter 8 Sekunden abgeschickt.
  // Bots bekommen eine Scheinbestätigung, gespeichert wird nichts.
  const tooFast = !b.started || Date.now() - Number(b.started) < 8000;
  if (str(b.website) !== '' || tooFast) return json({ ok: true, code: 'XXXX-XXXX' });

  const ip = await ipHash(request, env);
  const recent = await db.prepare('SELECT COUNT(*) AS n FROM applications WHERE ip_hash = ? AND created_at > ?').bind(ip, isoAgo(864e5)).first();
  if (recent.n >= 3) return json({ errors: ['Von deinem Anschluss kamen heute schon mehrere Bewerbungen. Versuch es morgen wieder.'] }, 429);

  const prev = await db.prepare('SELECT status, decided_at FROM applications WHERE discord_name = ? COLLATE NOCASE ORDER BY id DESC LIMIT 1').bind(d.discord_name).first();
  const cooldown = intEnv(env, 'COOLDOWN_DAYS', 7);
  if (prev) {
    if (prev.status === 'offen' || prev.status === 'pruefung') return json({ errors: ['Für diesen Discord-Namen läuft schon eine Bewerbung. Den Stand siehst du unter „Status prüfen“.'] }, 409);
    if (prev.status === 'angenommen') return json({ errors: ['Für diesen Discord-Namen wurde schon eine Bewerbung angenommen. Du bist schon im Team!'] }, 409);
    if (prev.decided_at && prev.decided_at > isoAgo(cooldown * 864e5)) return json({ errors: [`Nach einer Ablehnung kannst du dich erst nach ${cooldown} Tagen neu bewerben.`] }, 409);
  }

  let code, tries = 0;
  do { code = newCode(); tries++; } while (tries < 5 && (await db.prepare('SELECT 1 AS x FROM applications WHERE code = ?').bind(code).first()));

  const res = await db.prepare(
    `INSERT INTO applications (code, discord_name, discord_id, age, position, hours, times, experience, motivation, scenario1, scenario2, status, ip_hash, created_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?, 'offen', ?, ?)`
  ).bind(code, d.discord_name, d.discord_id || null, d.age, d.position, d.hours, d.times, d.experience, d.motivation, d.scenario1, d.scenario2, ip, now()).run();
  const id = res.meta?.last_row_id;
  try { await ensureSchema(db); await act(db, null, 'bewerbung', 'application', id, `Neue Bewerbung von ${q(d.discord_name)} als ${d.position}`).run(); } catch {}

  await discordNotify(env, ctx, {
    title: `Neue Team-Bewerbung #${id}`, color: 0xff4fb3, url: siteLink(env, `/admin/#bewerbung-${id}`),
    description: `**${d.discord_name}** möchte als **${d.position}** ins Team.`,
    fields: [
      { name: 'Discord', value: d.discord_name + (d.discord_id ? ` (<@${d.discord_id}>)` : ''), inline: true },
      { name: 'Alter', value: String(d.age), inline: true },
      { name: 'Zeit / Woche', value: d.hours, inline: true }
    ]
  });
  return json({ ok: true, code }, 201);
}

async function getStatus({ url, env }) {
  let code = (url.searchParams.get('code') || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (code.length !== 8) return fail('Bitte gib deinen 8-stelligen Code ein.');
  code = code.slice(0, 4) + '-' + code.slice(4);
  const a = await env.DB.prepare('SELECT position, status, public_note, created_at, decided_at FROM applications WHERE code = ?').bind(code).first();
  if (!a) return fail('Zu diesem Code haben wir keine Bewerbung gefunden. Prüf, ob du ihn richtig eingegeben hast.', 404);
  return json({ code, ...a, cooldownDays: intEnv(env, 'COOLDOWN_DAYS', 7) });
}

async function getSetup({ env }) {
  const n = await env.DB.prepare('SELECT COUNT(*) AS n FROM admins').first();
  return json({ needed: n.n === 0, keySet: !!env.SETUP_KEY });
}

async function postSetup({ request, env }) {
  const n = await env.DB.prepare('SELECT COUNT(*) AS n FROM admins').first();
  if (n.n > 0) throw new HttpError('Die Einrichtung ist bereits abgeschlossen.', 403);
  if (!env.SETUP_KEY) throw new HttpError('SETUP_KEY ist in Cloudflare nicht gesetzt. Siehe Anleitung.', 500);
  const b = await readBody(request);
  if (!safeEqual(str(b.key), env.SETUP_KEY)) throw new HttpError('Der Einrichtungsschlüssel ist falsch.', 403);
  const name = str(b.name, 40), pass = String(b.pass || '');
  if (!/^[A-Za-z0-9_.-]{3,40}$/.test(name)) throw new HttpError('Benutzername: 3–40 Zeichen, nur Buchstaben, Zahlen, Punkt, Strich und Unterstrich.');
  if (pass.length < 10) throw new HttpError('Das Passwort muss mindestens 10 Zeichen lang sein.');
  await env.DB.prepare("INSERT INTO admins (name, pass_hash, role, active, created_at) VALUES (?, ?, 'owner', 1, ?)").bind(name, await hashPassword(pass), now()).run();
  return json({ ok: true });
}

// ---------------------------------------------------------------- Login
async function postLogin({ request, env }) {
  const db = env.DB;
  const ip = await ipHash(request, env);
  await db.prepare('DELETE FROM login_attempts WHERE created_at < ?').bind(isoAgo(15 * 60e3)).run();
  const tries = await db.prepare('SELECT COUNT(*) AS n FROM login_attempts WHERE ip_hash = ?').bind(ip).first();
  if (tries.n >= 5) throw new HttpError('Zu viele Fehlversuche. Warte 15 Minuten und versuch es dann nochmal.', 429);

  const b = await readBody(request);
  const a = await db.prepare('SELECT id, name, role, pass_hash, active FROM admins WHERE name = ? COLLATE NOCASE').bind(str(b.name, 40)).first();
  if (!a || !a.active || !(await verifyPassword(String(b.pass || ''), a.pass_hash))) {
    await db.prepare('INSERT INTO login_attempts (ip_hash, created_at) VALUES (?, ?)').bind(ip, now()).run();
    throw new HttpError('Benutzername oder Passwort ist falsch.', 401);
  }
  const token = randomString(48, 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789');
  await db.batch([
    db.prepare('DELETE FROM sessions WHERE expires_at < ?').bind(now()),
    db.prepare('INSERT INTO sessions (token_hash, admin_id, expires_at) VALUES (?, ?, ?)').bind(await sha256(token), a.id, new Date(Date.now() + SESSION_HOURS * 3600e3).toISOString()),
    db.prepare('UPDATE admins SET last_login = ? WHERE id = ?').bind(now(), a.id),
    db.prepare('DELETE FROM login_attempts WHERE ip_hash = ?').bind(ip)
  ]);
  return json({ ok: true, me: { id: a.id, name: a.name, role: a.role } }, 200, { 'Set-Cookie': sessionCookie(request, token, SESSION_HOURS * 3600) });
}

async function postLogout({ request, env }) {
  const token = cookie(request, SESSION_COOKIE);
  if (token) await env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(await sha256(token)).run();
  return json({ ok: true }, 200, { 'Set-Cookie': sessionCookie(request, '', 0) });
}

// ---------------------------------------------------------------- Team-Panel
async function getMe({ request, env }) {
  return json({ me: await requireAdmin(request, env) });
}

async function listApplications({ request, env, url }) {
  await requireAdmin(request, env);
  const db = env.DB;
  const keep = intEnv(env, 'DELETE_AFTER_DAYS', 90);
  if (keep > 0) { // Datenschutz: alte, entschiedene Bewerbungen löschen
    const cut = isoAgo(keep * 864e5);
    await db.batch([
      db.prepare("DELETE FROM notes WHERE application_id IN (SELECT id FROM applications WHERE status IN ('angenommen','abgelehnt') AND decided_at < ?)").bind(cut),
      db.prepare("DELETE FROM applications WHERE status IN ('angenommen','abgelehnt') AND decided_at < ?").bind(cut)
    ]);
  }
  const counts = { offen: 0, pruefung: 0, angenommen: 0, abgelehnt: 0 };
  for (const r of (await db.prepare('SELECT status, COUNT(*) AS n FROM applications GROUP BY status').all()).results) counts[r.status] = r.n;

  const status = url.searchParams.get('status') || 'aktiv';
  const position = url.searchParams.get('position') || '';
  const q = (url.searchParams.get('q') || '').trim().toLowerCase();
  const where = [], args = [];
  if (status === 'aktiv') where.push("a.status IN ('offen','pruefung')");
  else if (STATUSES.includes(status)) { where.push('a.status = ?'); args.push(status); }
  if (position) { where.push('a.position = ?'); args.push(position); }
  if (q) { where.push('(LOWER(a.discord_name) LIKE ? OR LOWER(a.position) LIKE ? OR LOWER(a.code) LIKE ? OR a.discord_id LIKE ?)'); args.push(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`); }
  const sql = `SELECT a.id, a.discord_name, a.position, a.age, a.hours, a.status, a.created_at, d.name AS decided_by_name
    FROM applications a LEFT JOIN admins d ON d.id = a.decided_by ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY a.id ${status === 'aktiv' ? 'ASC' : 'DESC'} LIMIT 300`;
  const rows = (await db.prepare(sql).bind(...args).all()).results;
  return json({ counts, rows });
}

async function getApplication({ request, env, params }) {
  await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const app = await db.prepare('SELECT a.*, d.name AS decided_by_name FROM applications a LEFT JOIN admins d ON d.id = a.decided_by WHERE a.id = ?').bind(id).first();
  if (!app) throw new HttpError('Diese Bewerbung gibt es nicht (mehr).', 404);
  delete app.ip_hash;
  const notes = (await db.prepare('SELECT n.id, n.body, n.kind, n.created_at, a.name AS admin_name FROM notes n LEFT JOIN admins a ON a.id = n.admin_id WHERE n.application_id = ? ORDER BY n.id DESC').bind(id).all()).results;
  const previous = (await db.prepare('SELECT id, status, created_at FROM applications WHERE discord_name = ? COLLATE NOCASE AND id <> ? ORDER BY id DESC').bind(app.discord_name, id).all()).results;
  return json({ app, notes, previous });
}

async function setStatus({ request, env, params, ctx }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const b = await readBody(request);
  const next = String(b.status || ''), msg = str(b.public_note, 2000);
  if (!STATUSES.includes(next)) throw new HttpError('Unbekannter Status.');
  const app = await db.prepare('SELECT id, status, discord_name, discord_id, position, public_note FROM applications WHERE id = ?').bind(id).first();
  if (!app) throw new HttpError('Diese Bewerbung gibt es nicht (mehr).', 404);
  if (app.status === next) return json({ ok: true });
  const final = next === 'angenommen' || next === 'abgelehnt';
  await db.batch([
    db.prepare('UPDATE applications SET status = ?, public_note = ?, decided_by = ?, decided_at = ? WHERE id = ?')
      .bind(next, msg || (final ? null : app.public_note), me.id, final ? now() : null, id),
    db.prepare("INSERT INTO notes (application_id, admin_id, body, kind, created_at) VALUES (?, ?, ?, 'system', ?)")
      .bind(id, me.id, `Status geändert: ${LABEL[app.status]} → ${LABEL[next]}` + (msg ? `\nNachricht an Bewerber: ${msg}` : ''), now()),
    act(db, me, 'bewerbung', 'application', id, `hat die Bewerbung von ${q(app.discord_name)} auf „${LABEL[next]}“ gesetzt`)
  ]);
  if (final) {
    await discordNotify(env, ctx, {
      title: `${next === 'angenommen' ? '✅ Angenommen' : '❌ Abgelehnt'}: ${app.discord_name}`, color: next === 'angenommen' ? 0x4fe0a0 : 0xff5a6e,
      description: `Team-Bewerbung #${id} als **${app.position}**${app.discord_id ? ` von <@${app.discord_id}>` : ''} wurde von ${me.name} ${next === 'angenommen' ? 'angenommen' : 'abgelehnt'}.`
    });
  }
  return json({ ok: true });
}

async function addNote({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const b = await readBody(request);
  const body = str(b.body, 4000);
  if (!body) throw new HttpError('Die Notiz ist leer.');
  const exists = await env.DB.prepare('SELECT 1 AS x FROM applications WHERE id = ?').bind(Number(params.id)).first();
  if (!exists) throw new HttpError('Diese Bewerbung gibt es nicht (mehr).', 404);
  await env.DB.batch([
    env.DB.prepare("INSERT INTO notes (application_id, admin_id, body, kind, created_at) VALUES (?, ?, ?, 'note', ?)").bind(Number(params.id), me.id, body, now()),
    act(env.DB, me, 'bewerbung', 'application', Number(params.id), `hat eine Notiz zu Bewerbung #${params.id} geschrieben`)
  ]);
  return json({ ok: true });
}

async function deleteApplication({ request, env, params }) {
  const me = await requireAdmin(request, env, true);
  const id = Number(params.id), db = env.DB;
  await db.batch([db.prepare('DELETE FROM notes WHERE application_id = ?').bind(id), db.prepare('DELETE FROM applications WHERE id = ?').bind(id), act(db, me, 'bewerbung', 'application', id, `hat Bewerbung #${id} gelöscht`)]);
  return json({ ok: true });
}

async function getTeam({ request, env }) {
  await requireAdmin(request, env);
  const rows = (await env.DB.prepare('SELECT id, name, role, active, created_at, last_login FROM admins ORDER BY role DESC, name').all()).results;
  return json({ team: rows });
}

async function createTeam({ request, env }) {
  const me = await requireAdmin(request, env, true);
  const b = await readBody(request);
  const name = str(b.name, 40), role = b.role === 'owner' ? 'owner' : 'admin';
  if (!/^[A-Za-z0-9_.-]{3,40}$/.test(name)) throw new HttpError('Benutzername: 3–40 Zeichen, nur Buchstaben, Zahlen, Punkt, Strich und Unterstrich.');
  if (await env.DB.prepare('SELECT 1 AS x FROM admins WHERE name = ? COLLATE NOCASE').bind(name).first()) throw new HttpError('Diesen Benutzernamen gibt es schon.', 409);
  const pass = newPassword();
  await env.DB.prepare('INSERT INTO admins (name, pass_hash, role, active, created_at) VALUES (?, ?, ?, 1, ?)').bind(name, await hashPassword(pass), role, now()).run();
  await act(env.DB, me, 'team', 'admin', null, `hat das Team-Konto ${q(name)} angelegt (${role === 'owner' ? 'Owner' : 'Admin'})`).run();
  return json({ ok: true, name, password: pass }, 201);
}

async function updateTeam({ request, env, params }) {
  const me = await requireAdmin(request, env, true);
  const id = Number(params.id), db = env.DB;
  if (id === me.id) throw new HttpError('Dein eigenes Konto änderst du unter „Mein Konto“.');
  const t = await db.prepare('SELECT id, name, active FROM admins WHERE id = ?').bind(id).first();
  if (!t) throw new HttpError('Dieses Konto gibt es nicht.', 404);
  const b = await readBody(request);
  if (b.action === 'toggle') {
    await db.batch([db.prepare('UPDATE admins SET active = 1 - active WHERE id = ?').bind(id), db.prepare('DELETE FROM sessions WHERE admin_id = ?').bind(id), act(db, me, 'team', 'admin', id, `hat ${q(t.name)} ${t.active ? 'gesperrt' : 'entsperrt'}`)]);
    return json({ ok: true });
  }
  if (b.action === 'reset') {
    const pass = newPassword();
    await db.batch([db.prepare('UPDATE admins SET pass_hash = ? WHERE id = ?').bind(await hashPassword(pass), id), db.prepare('DELETE FROM sessions WHERE admin_id = ?').bind(id), act(db, me, 'team', 'admin', id, `hat für ${q(t.name)} ein neues Passwort erstellt`)]);
    return json({ ok: true, name: t.name, password: pass });
  }
  if (b.action === 'role') {
    await db.batch([db.prepare('UPDATE admins SET role = ? WHERE id = ?').bind(b.role === 'owner' ? 'owner' : 'admin', id), act(db, me, 'team', 'admin', id, `hat ${q(t.name)} zum ${b.role === 'owner' ? 'Owner' : 'Admin'} gemacht`)]);
    return json({ ok: true });
  }
  throw new HttpError('Unbekannte Aktion.');
}

async function changePassword({ request, env }) {
  const me = await requireAdmin(request, env);
  const b = await readBody(request);
  const row = await env.DB.prepare('SELECT pass_hash FROM admins WHERE id = ?').bind(me.id).first();
  if (!(await verifyPassword(String(b.old || ''), row.pass_hash))) throw new HttpError('Dein aktuelles Passwort stimmt nicht.', 403);
  if (String(b.new || '').length < 10) throw new HttpError('Das neue Passwort muss mindestens 10 Zeichen lang sein.');
  const token = cookie(request, SESSION_COOKIE);
  await env.DB.batch([
    env.DB.prepare('UPDATE admins SET pass_hash = ? WHERE id = ?').bind(await hashPassword(String(b.new)), me.id),
    env.DB.prepare('DELETE FROM sessions WHERE admin_id = ? AND token_hash <> ?').bind(me.id, await sha256(token || ''))
  ]);
  return json({ ok: true });
}

async function saveSettings({ request, env }) {
  const me = await requireAdmin(request, env, true);
  const b = await readBody(request);
  const states = ['offen', 'wenige', 'voll', 'geschlossen'];
  const positions = (Array.isArray(b.positions) ? b.positions : [])
    .map((p) => ({ name: str(p.name, 40), state: states.includes(p.state) ? p.state : 'offen' }))
    .filter((p) => p.name).slice(0, 20);
  if (!positions.length) throw new HttpError('Es muss mindestens einen Bereich geben.');
  if (new Set(positions.map((p) => p.name.toLowerCase())).size !== positions.length) throw new HttpError('Jeder Bereich darf nur einmal vorkommen.');
  await env.DB.batch([
    env.DB.prepare("INSERT INTO settings (key, value) VALUES ('applications_open', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").bind(b.open ? 'true' : 'false'),
    env.DB.prepare("INSERT INTO settings (key, value) VALUES ('positions', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").bind(JSON.stringify(positions)),
    act(env.DB, me, 'team', 'settings', null, `hat die Bewerbungs-Einstellungen geändert (${b.open ? 'geöffnet' : 'pausiert'})`)
  ]);
  return json({ ok: true });
}

// ---------------------------------------------------------------- Panel-Erweiterungen: Tabellen
// Alle Tabellen werden automatisch angelegt (CREATE TABLE IF NOT EXISTS), du musst nichts von Hand ausführen.
const PANEL_SCHEMA = [
  `CREATE TABLE IF NOT EXISTS activity (id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER, kind TEXT NOT NULL, ref_type TEXT, ref_id INTEGER, text TEXT NOT NULL, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS presence (admin_id INTEGER PRIMARY KEY, last_seen TEXT NOT NULL, view TEXT)`,
  `CREATE TABLE IF NOT EXISTS announcements (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT, pinned INTEGER NOT NULL DEFAULT 0, admin_id INTEGER, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS players (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, discord TEXT, license TEXT, notes TEXT, watch INTEGER NOT NULL DEFAULT 0, created_by INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS sanctions (id INTEGER PRIMARY KEY AUTOINCREMENT, player_id INTEGER NOT NULL, type TEXT NOT NULL, reason TEXT NOT NULL, duration TEXT, expires_at TEXT, active INTEGER NOT NULL DEFAULT 1, admin_id INTEGER, created_at TEXT NOT NULL, lifted_by INTEGER, lifted_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS news (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT, tag TEXT NOT NULL DEFAULT 'Ankündigung', published INTEGER NOT NULL DEFAULT 0, pinned INTEGER NOT NULL DEFAULT 0, admin_id INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS dev_milestones (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT, target TEXT, status TEXT NOT NULL DEFAULT 'geplant', sort INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS dev_tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT, status TEXT NOT NULL DEFAULT 'todo', priority TEXT NOT NULL DEFAULT 'normal', category TEXT NOT NULL DEFAULT 'Sonstiges', assignee_id INTEGER, milestone_id INTEGER, due TEXT, created_by INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS dev_comments (id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER NOT NULL, admin_id INTEGER, body TEXT NOT NULL, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS dev_checks (id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER NOT NULL, text TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0, sort INTEGER NOT NULL DEFAULT 0)`,
  `CREATE TABLE IF NOT EXISTS dev_resources (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, version TEXT, kind TEXT, status TEXT NOT NULL DEFAULT 'aktiv', source TEXT, notes TEXT, admin_id INTEGER, updated_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS dev_docs (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT, category TEXT, admin_id INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_dev_tasks_status ON dev_tasks(status)`,
  `CREATE INDEX IF NOT EXISTS idx_sanctions_player ON sanctions(player_id)`,
  `CREATE INDEX IF NOT EXISTS idx_comments_task ON dev_comments(task_id)`,
  `CREATE INDEX IF NOT EXISTS idx_checks_task ON dev_checks(task_id)`
];
let schemaReady = false;
// Neue Spalten für bestehende Tabellen (ältere Datenbanken bekommen sie automatisch nachgerüstet)
const COLUMN_MIGRATIONS = [
  ['dev_milestones', 'start_date', 'TEXT'], ['dev_milestones', 'end_date', 'TEXT'], ['dev_milestones', 'goal', 'TEXT'],
  ['dev_milestones', 'owner_id', 'INTEGER'], ['dev_milestones', 'public', 'INTEGER NOT NULL DEFAULT 0']
];
async function ensureSchema(db) {
  if (schemaReady) return;
  await db.batch(PANEL_SCHEMA.map((s) => db.prepare(s)));
  const tables = [...new Set(COLUMN_MIGRATIONS.map((m) => m[0]))];
  for (const t of tables) {
    const cols = new Set((await all(db.prepare(`PRAGMA table_info(${t})`))).map((c) => c.name));
    for (const [tt, col, type] of COLUMN_MIGRATIONS) if (tt === t && !cols.has(col)) {
      try { await db.prepare(`ALTER TABLE ${t} ADD COLUMN ${col} ${type}`).run(); } catch (e) { if (!/duplicate column/i.test(String(e))) throw e; }
    }
  }
  schemaReady = true;
}

// Protokoll: jede Änderung wird festgehalten. Darüber läuft auch die Live-Aktualisierung.
const act = (db, me, kind, refType, refId, text) =>
  db.prepare('INSERT INTO activity (admin_id, kind, ref_type, ref_id, text, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .bind(me ? me.id : null, kind, refType, refId ?? null, String(text).slice(0, 300), now());
const q = (s) => `„${String(s).slice(0, 80)}“`;

const pick = (v, list, d) => (list.includes(v) ? v : d);
const dateOrNull = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) ? String(v) : null);
const idOrNull = (v) => { const n = parseInt(v, 10); return Number.isFinite(n) && n > 0 ? n : null; };
const has = (b, k) => Object.prototype.hasOwnProperty.call(b, k);
const all = async (stmt) => (await stmt.all()).results || [];

// ---------------------------------------------------------------- Live: Puls, Online-Liste, Suche
async function getPulse({ request, env, url }) {
  const me = await requireAdmin(request, env);
  const db = env.DB;
  const since = parseInt(url.searchParams.get('since'), 10) || 0;
  if (url.searchParams.get('touch')) {
    await db.prepare('INSERT INTO presence (admin_id, last_seen, view) VALUES (?, ?, ?) ON CONFLICT(admin_id) DO UPDATE SET last_seen = excluded.last_seen, view = excluded.view')
      .bind(me.id, now(), str(url.searchParams.get('view'), 30)).run();
  }
  const [rev, events, online] = await Promise.all([
    db.prepare('SELECT COALESCE(MAX(id), 0) AS r FROM activity').first(),
    since ? all(db.prepare('SELECT v.id, v.admin_id, v.kind, v.ref_type, v.ref_id, v.text, v.created_at, a.name AS admin_name FROM activity v LEFT JOIN admins a ON a.id = v.admin_id WHERE v.id > ? ORDER BY v.id DESC LIMIT 15').bind(since)) : [],
    all(db.prepare('SELECT a.id, a.name, p.view, p.last_seen FROM presence p JOIN admins a ON a.id = p.admin_id WHERE p.last_seen > ? AND a.active = 1 ORDER BY a.name').bind(isoAgo(75e3)))
  ]);
  const badges = await db.prepare("SELECT (SELECT COUNT(*) FROM applications WHERE status IN ('offen','pruefung')) AS apps, (SELECT COUNT(*) FROM dev_tasks WHERE category = 'Bug' AND status <> 'fertig') AS bugs, (SELECT COUNT(*) FROM team_records WHERE kind = 'verwarnung' AND admin_id = ? AND ack_at IS NULL AND lifted_at IS NULL AND created_at > '2026-11-10') AS tw").bind(me.id).first();
  return json({ rev: rev.r, events, online, badges });
}

async function getSearch({ request, env, url }) {
  await requireAdmin(request, env);
  const db = env.DB, term = str(url.searchParams.get('q'), 60).toLowerCase();
  if (term.length < 2) return json({ results: [] });
  const like = `%${term}%`;
  const [apps, players, tasks, docs, res, plan] = await Promise.all([
    all(db.prepare('SELECT id, discord_name AS title, position AS sub FROM applications WHERE LOWER(discord_name) LIKE ? OR LOWER(code) LIKE ? ORDER BY id DESC LIMIT 5').bind(like, like)),
    all(db.prepare('SELECT id, name AS title, discord AS sub FROM players WHERE LOWER(name) LIKE ? OR LOWER(COALESCE(discord,\'\')) LIKE ? OR LOWER(COALESCE(license,\'\')) LIKE ? ORDER BY updated_at DESC LIMIT 5').bind(like, like, like)),
    all(db.prepare('SELECT id, title, status AS sub FROM dev_tasks WHERE LOWER(title) LIKE ? OR LOWER(COALESCE(body,\'\')) LIKE ? ORDER BY updated_at DESC LIMIT 6').bind(like, like)),
    all(db.prepare('SELECT id, title, category AS sub FROM dev_docs WHERE LOWER(title) LIKE ? OR LOWER(COALESCE(body,\'\')) LIKE ? ORDER BY updated_at DESC LIMIT 5').bind(like, like)),
    all(db.prepare('SELECT id, name AS title, status AS sub FROM dev_resources WHERE LOWER(name) LIKE ? OR LOWER(COALESCE(notes,\'\')) LIKE ? ORDER BY name LIMIT 5').bind(like, like)),
    all(db.prepare('SELECT id, title, CASE area WHEN \'social\' THEN \'Social Media\' WHEN \'events\' THEN \'Events\' WHEN \'frak\' THEN \'Fraktionen\' WHEN \'docs\' THEN \'Teamdokumente\' ELSE \'Projekt\' END AS sub FROM plan_items WHERE LOWER(title) LIKE ? OR LOWER(COALESCE(data,\'\')) LIKE ? ORDER BY updated_at DESC LIMIT 8').bind(like, like))
  ]);
  const tag = (type, rows) => rows.map((r) => ({ type, ...r }));
  return json({ results: [...tag('bewerbung', apps), ...tag('spieler', players), ...tag('aufgabe', tasks), ...tag('wiki', docs), ...tag('script', res), ...tag('plan', plan)] });
}

// ---------------------------------------------------------------- Übersicht & Pinnwand
async function getDashboard({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, n = now();
  const one = (sql, ...a) => db.prepare(sql).bind(...a).first();
  const [apps, myTasks, bugs, bans, players, prog, ann, feed, mine, news] = await Promise.all([
    one("SELECT SUM(status = 'offen') AS offen, SUM(status = 'pruefung') AS pruefung FROM applications"),
    one("SELECT COUNT(*) AS n FROM dev_tasks WHERE assignee_id = ? AND status <> 'fertig'", me.id),
    one("SELECT COUNT(*) AS n FROM dev_tasks WHERE category = 'Bug' AND status <> 'fertig'"),
    one("SELECT COUNT(DISTINCT player_id) AS n FROM sanctions WHERE type IN ('ban','permaban') AND active = 1 AND (expires_at IS NULL OR expires_at > ?)", n),
    one('SELECT COUNT(*) AS n FROM players'),
    one("SELECT COUNT(*) AS total, SUM(status = 'fertig') AS done FROM dev_tasks"),
    all(db.prepare('SELECT x.*, a.name AS admin_name FROM announcements x LEFT JOIN admins a ON a.id = x.admin_id ORDER BY x.pinned DESC, x.id DESC LIMIT 12')),
    all(db.prepare('SELECT v.*, a.name AS admin_name FROM activity v LEFT JOIN admins a ON a.id = v.admin_id ORDER BY v.id DESC LIMIT 14')),
    all(db.prepare("SELECT id, title, status, priority, due, category FROM dev_tasks WHERE assignee_id = ? AND status <> 'fertig' ORDER BY CASE priority WHEN 'kritisch' THEN 0 WHEN 'hoch' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END, due IS NULL, due LIMIT 8").bind(me.id)),
    one('SELECT COUNT(*) AS n FROM news WHERE published = 1')
  ]);
  const today = n.slice(0, 10);
  const [upcoming, away, openPolls] = await Promise.all([
    all(db.prepare(`SELECT e.id, e.title, e.kind, e.starts_at, e.location, (SELECT status FROM event_rsvp r WHERE r.event_id = e.id AND r.admin_id = ?) AS mine,
        (SELECT COUNT(*) FROM event_rsvp r WHERE r.event_id = e.id AND r.status = 'ja') AS yes FROM events e WHERE e.starts_at > ? ORDER BY e.starts_at LIMIT 4`).bind(me.id, isoAgo(2 * 3600e3))),
    all(db.prepare('SELECT x.id, x.to_date, x.reason, a.name FROM absences x JOIN admins a ON a.id = x.admin_id WHERE x.from_date <= ? AND x.to_date >= ? ORDER BY x.to_date').bind(today, today)),
    all(db.prepare('SELECT p.id, p.question, p.closes_at FROM polls p WHERE p.closed = 0 AND (p.closes_at IS NULL OR p.closes_at > ?) AND NOT EXISTS (SELECT 1 FROM poll_votes v WHERE v.poll_id = p.id AND v.admin_id = ?) ORDER BY p.id DESC LIMIT 4').bind(n, me.id))
  ]);
  return json({
    team: { upcoming, away, openPolls },
    stats: { appsOpen: apps.offen || 0, appsReview: apps.pruefung || 0, myTasks: myTasks.n, bugs: bugs.n, bans: bans.n, players: players.n, tasksTotal: prog.total || 0, tasksDone: prog.done || 0, news: news.n },
    announcements: ann, feed, mine
  });
}

async function createAnnouncement({ request, env }) {
  const me = await requireAdmin(request, env);
  const b = await readBody(request);
  const title = str(b.title, 120), body = str(b.body, 2000);
  if (len(title) < 2) throw new HttpError('Gib der Nachricht einen Titel.');
  const db = env.DB;
  const r = await db.prepare('INSERT INTO announcements (title, body, pinned, admin_id, created_at) VALUES (?, ?, ?, ?, ?)').bind(title, body, b.pinned ? 1 : 0, me.id, now()).run();
  await act(db, me, 'pinnwand', 'announcement', r.meta.last_row_id, `hat an die Pinnwand geschrieben: ${q(title)}`).run();
  return json({ ok: true }, 201);
}
async function updateAnnouncement({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id), b = await readBody(request);
  const x = await db.prepare('SELECT * FROM announcements WHERE id = ?').bind(id).first();
  if (!x) throw new HttpError('Diese Nachricht gibt es nicht mehr.', 404);
  await db.batch([
    db.prepare('UPDATE announcements SET pinned = ? WHERE id = ?').bind(b.pinned ? 1 : 0, id),
    act(db, me, 'pinnwand', 'announcement', id, `hat ${q(x.title)} ${b.pinned ? 'angeheftet' : 'gelöst'}`)
  ]);
  return json({ ok: true });
}
async function deleteAnnouncement({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const x = await db.prepare('SELECT * FROM announcements WHERE id = ?').bind(id).first();
  if (!x) return json({ ok: true });
  if (x.admin_id !== me.id && me.role !== 'owner') throw new HttpError('Nur der Verfasser oder der Owner darf das löschen.', 403);
  await db.batch([db.prepare('DELETE FROM announcements WHERE id = ?').bind(id), act(db, me, 'pinnwand', 'announcement', id, `hat ${q(x.title)} von der Pinnwand genommen`)]);
  return json({ ok: true });
}

async function getActivity({ request, env, url }) {
  await requireAdmin(request, env);
  const before = parseInt(url.searchParams.get('before'), 10) || 0;
  const who = parseInt(url.searchParams.get('who'), 10) || 0;
  const kind = str(url.searchParams.get('kind'), 20);
  const where = [], args = [];
  if (before) { where.push('v.id < ?'); args.push(before); }
  if (who) { where.push('v.admin_id = ?'); args.push(who); }
  if (kind) { where.push('v.kind = ?'); args.push(kind); }
  const rows = await all(env.DB.prepare(`SELECT v.*, a.name AS admin_name FROM activity v LEFT JOIN admins a ON a.id = v.admin_id ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY v.id DESC LIMIT 80`).bind(...args));
  const team = await all(env.DB.prepare('SELECT id, name FROM admins ORDER BY name'));
  return json({ rows, team });
}

// ---------------------------------------------------------------- Spielerakten & Sanktionen
const SANCTIONS = ['hinweis', 'verwarnung', 'kick', 'ban', 'permaban'];
const SANCTION_LABEL = { hinweis: 'Hinweis', verwarnung: 'Verwarnung', kick: 'Kick', ban: 'Ban', permaban: 'Permanenter Ban' };

async function listPlayers({ request, env, url }) {
  await requireAdmin(request, env);
  const db = env.DB, n = now();
  const term = str(url.searchParams.get('q'), 60).toLowerCase(), filter = url.searchParams.get('filter') || '';
  const where = [], args = [n];
  if (term) { where.push("(LOWER(p.name) LIKE ? OR LOWER(COALESCE(p.discord,'')) LIKE ? OR LOWER(COALESCE(p.license,'')) LIKE ?)"); args.push(`%${term}%`, `%${term}%`, `%${term}%`); }
  if (filter === 'beobachten') where.push('p.watch = 1');
  const rows = await all(db.prepare(`SELECT p.id, p.name, p.discord, p.license, p.watch, p.updated_at,
      (SELECT COUNT(*) FROM sanctions s WHERE s.player_id = p.id AND s.type = 'verwarnung' AND s.active = 1) AS warns,
      (SELECT COUNT(*) FROM sanctions s WHERE s.player_id = p.id) AS total,
      (SELECT COALESCE(s.expires_at, '') || '|' || s.type FROM sanctions s WHERE s.player_id = p.id AND s.type IN ('ban','permaban') AND s.active = 1 AND (s.expires_at IS NULL OR s.expires_at > ?) ORDER BY s.expires_at IS NULL DESC, s.expires_at DESC LIMIT 1) AS ban
    FROM players p ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY p.updated_at DESC LIMIT 300`).bind(...args));
  const out = rows.map((r) => ({ ...r, ban: r.ban ? { until: r.ban.split('|')[0] || null, type: r.ban.split('|')[1] } : null }));
  return json({ rows: filter === 'gebannt' ? out.filter((r) => r.ban) : filter === 'verwarnt' ? out.filter((r) => r.warns > 0) : out });
}

function playerFields(b, old = {}) {
  const p = {
    name: has(b, 'name') ? str(b.name, 60) : old.name,
    discord: has(b, 'discord') ? str(b.discord, 60) : old.discord ?? '',
    license: has(b, 'license') ? str(b.license, 120) : old.license ?? '',
    notes: has(b, 'notes') ? str(b.notes, 6000) : old.notes ?? '',
    watch: has(b, 'watch') ? (b.watch ? 1 : 0) : old.watch ?? 0
  };
  if (len(p.name) < 2) throw new HttpError('Gib den Namen des Spielers an (Ingame- oder FiveM-Name).');
  return p;
}
async function createPlayer({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, p = playerFields(await readBody(request));
  const r = await db.prepare('INSERT INTO players (name, discord, license, notes, watch, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(p.name, p.discord, p.license, p.notes, p.watch, me.id, now(), now()).run();
  const id = r.meta.last_row_id;
  await act(db, me, 'spieler', 'player', id, `hat eine Spielerakte für ${q(p.name)} angelegt`).run();
  return json({ ok: true, id }, 201);
}
async function getPlayer({ request, env, params }) {
  await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const p = await db.prepare('SELECT p.*, c.name AS created_by_name FROM players p LEFT JOIN admins c ON c.id = p.created_by WHERE p.id = ?').bind(id).first();
  if (!p) throw new HttpError('Diese Spielerakte gibt es nicht.', 404);
  const s = await all(db.prepare('SELECT s.*, a.name AS admin_name, l.name AS lifted_by_name FROM sanctions s LEFT JOIN admins a ON a.id = s.admin_id LEFT JOIN admins l ON l.id = s.lifted_by WHERE s.player_id = ? ORDER BY s.id DESC').bind(id));
  return json({ player: p, sanctions: s, now: now() });
}
async function updatePlayer({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT * FROM players WHERE id = ?').bind(id).first();
  if (!old) throw new HttpError('Diese Spielerakte gibt es nicht.', 404);
  const b = await readBody(request), p = playerFields(b, old);
  const text = has(b, 'watch') && Object.keys(b).length === 1 ? `${p.watch ? 'beobachtet jetzt' : 'beobachtet nicht mehr'} ${q(p.name)}`
    : has(b, 'notes') && Object.keys(b).length === 1 ? `hat die Notizen zu ${q(p.name)} ergänzt` : `hat die Akte von ${q(p.name)} bearbeitet`;
  await db.batch([
    db.prepare('UPDATE players SET name = ?, discord = ?, license = ?, notes = ?, watch = ?, updated_at = ? WHERE id = ?').bind(p.name, p.discord, p.license, p.notes, p.watch, now(), id),
    act(db, me, 'spieler', 'player', id, text)
  ]);
  return json({ ok: true });
}
async function deletePlayer({ request, env, params }) {
  const me = await requireAdmin(request, env, true);
  const db = env.DB, id = Number(params.id);
  const p = await db.prepare('SELECT name FROM players WHERE id = ?').bind(id).first();
  if (!p) return json({ ok: true });
  await db.batch([db.prepare('DELETE FROM sanctions WHERE player_id = ?').bind(id), db.prepare('DELETE FROM players WHERE id = ?').bind(id), act(db, me, 'spieler', 'player', id, `hat die Spielerakte ${q(p.name)} gelöscht`)]);
  return json({ ok: true });
}
async function addSanction({ request, env, params, ctx }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const p = await db.prepare('SELECT id, name FROM players WHERE id = ?').bind(id).first();
  if (!p) throw new HttpError('Diese Spielerakte gibt es nicht.', 404);
  const b = await readBody(request);
  const type = pick(b.type, SANCTIONS, ''), reason = str(b.reason, 1000);
  if (!type) throw new HttpError('Wähl die Art der Sanktion.');
  if (len(reason) < 3) throw new HttpError('Gib einen Grund an, z. B. „RDM am Würfelpark“.');
  let expires = null, duration = null;
  if (type === 'ban') {
    const hours = Number(b.hours);
    if (!(hours > 0 && hours <= 24 * 365)) throw new HttpError('Wähl eine Ban-Dauer.');
    expires = new Date(Date.now() + hours * 3600e3).toISOString();
    duration = hours < 24 ? `${hours} Std.` : `${Math.round(hours / 24)} Tag${hours === 24 ? '' : 'e'}`;
  }
  if (type === 'permaban') duration = 'permanent';
  await db.batch([
    db.prepare('INSERT INTO sanctions (player_id, type, reason, duration, expires_at, active, admin_id, created_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?)').bind(id, type, reason, duration, expires, me.id, now()),
    db.prepare('UPDATE players SET updated_at = ? WHERE id = ?').bind(now(), id),
    act(db, me, 'spieler', 'player', id, `hat ${q(p.name)} sanktioniert: ${SANCTION_LABEL[type]}${duration && type === 'ban' ? ' (' + duration + ')' : ''}`)
  ]);
  if (type === 'ban' || type === 'permaban' || type === 'kick') {
    const full = await db.prepare('SELECT license FROM players WHERE id = ?').bind(id).first();
    try { await queueKickForLicense(db, full && full.license, type === 'kick' ? `Gekickt: ${reason}` : `Gebannt (${duration}): ${reason}`, me.id); } catch {}
  }
  if (type === 'ban' || type === 'permaban') {
    await discordNotify(env, ctx, { title: `🔨 ${SANCTION_LABEL[type]}: ${p.name}`, color: 0xff5a6e, description: `**Grund:** ${reason}\n**Dauer:** ${duration}\n**Von:** ${me.name}` });
  }
  return json({ ok: true }, 201);
}
async function liftSanction({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const s = await db.prepare('SELECT s.*, p.name FROM sanctions s JOIN players p ON p.id = s.player_id WHERE s.id = ?').bind(id).first();
  if (!s) throw new HttpError('Diese Sanktion gibt es nicht.', 404);
  await db.batch([
    db.prepare('UPDATE sanctions SET active = 0, lifted_by = ?, lifted_at = ? WHERE id = ?').bind(me.id, now(), id),
    db.prepare('UPDATE players SET updated_at = ? WHERE id = ?').bind(now(), s.player_id),
    act(db, me, 'spieler', 'player', s.player_id, `hat bei ${q(s.name)} eine Sanktion aufgehoben (${SANCTION_LABEL[s.type]})`)
  ]);
  return json({ ok: true });
}
async function deleteSanction({ request, env, params }) {
  const me = await requireAdmin(request, env, true);
  const db = env.DB, id = Number(params.id);
  const s = await db.prepare('SELECT s.*, p.name FROM sanctions s JOIN players p ON p.id = s.player_id WHERE s.id = ?').bind(id).first();
  if (!s) return json({ ok: true });
  await db.batch([db.prepare('DELETE FROM sanctions WHERE id = ?').bind(id), act(db, me, 'spieler', 'player', s.player_id, `hat bei ${q(s.name)} einen Eintrag gelöscht (${SANCTION_LABEL[s.type]})`)]);
  return json({ ok: true });
}

// ---------------------------------------------------------------- News für die Startseite
const NEWS_TAGS = ['Ankündigung', 'Update', 'Event', 'Team', 'Changelog', 'Release'];
async function getPublicNews({ env }) {
  await ensureSchema(env.DB);
  const rows = await all(env.DB.prepare('SELECT id, title, body, tag, pinned, created_at FROM news WHERE published = 1 ORDER BY pinned DESC, id DESC LIMIT 4'));
  return new Response(JSON.stringify({ rows }), { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=30', 'Access-Control-Allow-Origin': '*' } });
}
async function listNews({ request, env }) {
  await requireAdmin(request, env);
  return json({ rows: await all(env.DB.prepare('SELECT n.*, a.name AS admin_name FROM news n LEFT JOIN admins a ON a.id = n.admin_id ORDER BY n.pinned DESC, n.id DESC')), tags: NEWS_TAGS });
}
function newsFields(b, old = {}) {
  const n = {
    title: has(b, 'title') ? str(b.title, 120) : old.title,
    body: has(b, 'body') ? str(b.body, 4000) : old.body ?? '',
    tag: has(b, 'tag') ? pick(b.tag, NEWS_TAGS, 'Ankündigung') : old.tag ?? 'Ankündigung',
    published: has(b, 'published') ? (b.published ? 1 : 0) : old.published ?? 0,
    pinned: has(b, 'pinned') ? (b.pinned ? 1 : 0) : old.pinned ?? 0
  };
  if (len(n.title) < 3) throw new HttpError('Gib der News eine Überschrift.');
  return n;
}
async function createNews({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, n = newsFields(await readBody(request));
  const r = await db.prepare('INSERT INTO news (title, body, tag, published, pinned, admin_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').bind(n.title, n.body, n.tag, n.published, n.pinned, me.id, now(), now()).run();
  await act(db, me, 'news', 'news', r.meta.last_row_id, `hat die News ${q(n.title)} ${n.published ? 'veröffentlicht' : 'als Entwurf angelegt'}`).run();
  return json({ ok: true }, 201);
}
async function updateNews({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT * FROM news WHERE id = ?').bind(id).first();
  if (!old) throw new HttpError('Diese News gibt es nicht mehr.', 404);
  const n = newsFields(await readBody(request), old);
  const verb = n.published !== old.published ? (n.published ? 'veröffentlicht' : 'offline genommen') : 'bearbeitet';
  await db.batch([
    db.prepare('UPDATE news SET title = ?, body = ?, tag = ?, published = ?, pinned = ?, updated_at = ? WHERE id = ?').bind(n.title, n.body, n.tag, n.published, n.pinned, now(), id),
    act(db, me, 'news', 'news', id, `hat die News ${q(n.title)} ${verb}`)
  ]);
  return json({ ok: true });
}
async function deleteNews({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT title FROM news WHERE id = ?').bind(id).first();
  if (!old) return json({ ok: true });
  await db.batch([db.prepare('DELETE FROM news WHERE id = ?').bind(id), act(db, me, 'news', 'news', id, `hat die News ${q(old.title)} gelöscht`)]);
  return json({ ok: true });
}

// ---------------------------------------------------------------- Dev: Aufgaben, Roadmap, Checklisten, Kommentare
const TASK_STATUS = ['idee', 'todo', 'arbeit', 'test', 'fertig'];
const TASK_STATUS_LABEL = { idee: 'Ideen', todo: 'To-do', arbeit: 'In Arbeit', test: 'Testen', fertig: 'Fertig' };
const TASK_PRIO = ['niedrig', 'normal', 'hoch', 'kritisch'];
const TASK_CAT = ['Script', 'Mapping', 'Fahrzeuge', 'Kleidung', 'Fraktionen', 'Server', 'Website', 'Launcher', 'Discord', 'Bug', 'Sonstiges'];
const MS_STATUS = ['geplant', 'arbeit', 'fertig'];

async function getDev({ request, env }) {
  await requireAdmin(request, env);
  const db = env.DB;
  const [tasks, milestones, team] = await Promise.all([
    all(db.prepare(`SELECT t.*, a.name AS assignee_name, c.name AS created_by_name,
        (SELECT COUNT(*) FROM dev_comments k WHERE k.task_id = t.id) AS comments,
        (SELECT COUNT(*) FROM dev_checks h WHERE h.task_id = t.id) AS checks,
        (SELECT COUNT(*) FROM dev_checks h WHERE h.task_id = t.id AND h.done = 1) AS checks_done
      FROM dev_tasks t LEFT JOIN admins a ON a.id = t.assignee_id LEFT JOIN admins c ON c.id = t.created_by ORDER BY t.updated_at DESC`)),
    all(db.prepare('SELECT m.*, a.name AS owner_name FROM dev_milestones m LEFT JOIN admins a ON a.id = m.owner_id ORDER BY m.sort, m.start_date IS NULL, m.start_date, m.id')),
    all(db.prepare('SELECT id, name FROM admins WHERE active = 1 ORDER BY name'))
  ]);
  return json({ tasks, milestones, team, statuses: TASK_STATUS, priorities: TASK_PRIO, categories: TASK_CAT });
}

function taskFields(b, old = {}) {
  const t = {
    title: has(b, 'title') ? str(b.title, 120) : old.title,
    body: has(b, 'body') ? str(b.body, 4000) : old.body ?? '',
    status: has(b, 'status') ? pick(b.status, TASK_STATUS, 'todo') : old.status ?? 'todo',
    priority: has(b, 'priority') ? pick(b.priority, TASK_PRIO, 'normal') : old.priority ?? 'normal',
    category: has(b, 'category') ? pick(b.category, TASK_CAT, 'Sonstiges') : old.category ?? 'Sonstiges',
    assignee_id: has(b, 'assignee_id') ? idOrNull(b.assignee_id) : old.assignee_id ?? null,
    milestone_id: has(b, 'milestone_id') ? idOrNull(b.milestone_id) : old.milestone_id ?? null,
    due: has(b, 'due') ? dateOrNull(b.due) : old.due ?? null
  };
  if (!t.title || len(t.title) < 2) throw new HttpError('Gib der Aufgabe einen Titel.');
  return t;
}
async function getTask({ request, env, params }) {
  await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const t = await db.prepare('SELECT t.*, a.name AS assignee_name, c.name AS created_by_name FROM dev_tasks t LEFT JOIN admins a ON a.id = t.assignee_id LEFT JOIN admins c ON c.id = t.created_by WHERE t.id = ?').bind(id).first();
  if (!t) throw new HttpError('Diese Aufgabe gibt es nicht mehr.', 404);
  const [comments, checks] = await Promise.all([
    all(db.prepare('SELECT k.*, a.name AS admin_name FROM dev_comments k LEFT JOIN admins a ON a.id = k.admin_id WHERE k.task_id = ? ORDER BY k.id').bind(id)),
    all(db.prepare('SELECT * FROM dev_checks WHERE task_id = ? ORDER BY sort, id').bind(id))
  ]);
  return json({ task: t, comments, checks });
}
async function createTask({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, t = taskFields(await readBody(request));
  const r = await db.prepare(`INSERT INTO dev_tasks (title, body, status, priority, category, assignee_id, milestone_id, due, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(t.title, t.body, t.status, t.priority, t.category, t.assignee_id, t.milestone_id, t.due, me.id, now(), now()).run();
  const id = r.meta.last_row_id;
  await act(db, me, 'dev', 'task', id, t.category === 'Bug' ? `hat einen Bug gemeldet: ${q(t.title)}` : `hat die Aufgabe ${q(t.title)} angelegt`).run();
  return json({ ok: true, id }, 201);
}
async function updateTask({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB;
  const old = await db.prepare('SELECT * FROM dev_tasks WHERE id = ?').bind(Number(params.id)).first();
  if (!old) throw new HttpError('Diese Aufgabe gibt es nicht mehr.', 404);
  const t = taskFields(await readBody(request), old);
  const text = t.status !== old.status ? `hat ${q(t.title)} nach ${TASK_STATUS_LABEL[t.status]} verschoben`
    : t.assignee_id !== old.assignee_id ? `hat die Zuständigkeit für ${q(t.title)} geändert` : `hat die Aufgabe ${q(t.title)} bearbeitet`;
  await db.batch([
    db.prepare(`UPDATE dev_tasks SET title = ?, body = ?, status = ?, priority = ?, category = ?, assignee_id = ?, milestone_id = ?, due = ?, updated_at = ? WHERE id = ?`)
      .bind(t.title, t.body, t.status, t.priority, t.category, t.assignee_id, t.milestone_id, t.due, now(), old.id),
    act(db, me, 'dev', 'task', old.id, text)
  ]);
  return json({ ok: true });
}
async function deleteTask({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT title FROM dev_tasks WHERE id = ?').bind(id).first();
  if (!old) return json({ ok: true });
  await db.batch([
    db.prepare('DELETE FROM dev_comments WHERE task_id = ?').bind(id), db.prepare('DELETE FROM dev_checks WHERE task_id = ?').bind(id),
    db.prepare('DELETE FROM dev_tasks WHERE id = ?').bind(id), act(db, me, 'dev', 'task', id, `hat die Aufgabe ${q(old.title)} gelöscht`)
  ]);
  return json({ ok: true });
}
async function addComment({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id), body = str((await readBody(request)).body, 3000);
  if (!body) throw new HttpError('Der Kommentar ist leer.');
  const t = await db.prepare('SELECT title FROM dev_tasks WHERE id = ?').bind(id).first();
  if (!t) throw new HttpError('Diese Aufgabe gibt es nicht mehr.', 404);
  await db.batch([
    db.prepare('INSERT INTO dev_comments (task_id, admin_id, body, created_at) VALUES (?, ?, ?, ?)').bind(id, me.id, body, now()),
    db.prepare('UPDATE dev_tasks SET updated_at = ? WHERE id = ?').bind(now(), id),
    act(db, me, 'dev', 'task', id, `hat ${q(t.title)} kommentiert`)
  ]);
  return json({ ok: true }, 201);
}
async function addCheck({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id), text = str((await readBody(request)).text, 200);
  if (!text) throw new HttpError('Der Punkt ist leer.');
  const t = await db.prepare('SELECT title FROM dev_tasks WHERE id = ?').bind(id).first();
  if (!t) throw new HttpError('Diese Aufgabe gibt es nicht mehr.', 404);
  const max = await db.prepare('SELECT COALESCE(MAX(sort), 0) AS s FROM dev_checks WHERE task_id = ?').bind(id).first();
  await db.batch([
    db.prepare('INSERT INTO dev_checks (task_id, text, done, sort) VALUES (?, ?, 0, ?)').bind(id, text, max.s + 1),
    act(db, me, 'dev', 'task', id, `hat bei ${q(t.title)} einen Checklisten-Punkt ergänzt`)
  ]);
  return json({ ok: true }, 201);
}
async function updateCheck({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id), b = await readBody(request);
  const c = await db.prepare('SELECT h.*, t.title FROM dev_checks h JOIN dev_tasks t ON t.id = h.task_id WHERE h.id = ?').bind(id).first();
  if (!c) throw new HttpError('Diesen Punkt gibt es nicht mehr.', 404);
  const done = has(b, 'done') ? (b.done ? 1 : 0) : c.done;
  await db.batch([
    db.prepare('UPDATE dev_checks SET done = ? WHERE id = ?').bind(done, id),
    db.prepare('UPDATE dev_tasks SET updated_at = ? WHERE id = ?').bind(now(), c.task_id),
    act(db, me, 'dev', 'task', c.task_id, `hat bei ${q(c.title)} ${q(c.text)} ${done ? 'abgehakt' : 'wieder geöffnet'}`)
  ]);
  return json({ ok: true });
}
async function deleteCheck({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const c = await db.prepare('SELECT h.*, t.title FROM dev_checks h JOIN dev_tasks t ON t.id = h.task_id WHERE h.id = ?').bind(id).first();
  if (!c) return json({ ok: true });
  await db.batch([db.prepare('DELETE FROM dev_checks WHERE id = ?').bind(id), act(db, me, 'dev', 'task', c.task_id, `hat bei ${q(c.title)} einen Checklisten-Punkt entfernt`)]);
  return json({ ok: true });
}

function msFields(b, old = {}) {
  const m = {
    title: has(b, 'title') ? str(b.title, 80) : old.title,
    body: has(b, 'body') ? str(b.body, 2000) : old.body ?? '',
    target: has(b, 'target') ? str(b.target, 40) : old.target ?? '',
    status: has(b, 'status') ? pick(b.status, MS_STATUS, 'geplant') : old.status ?? 'geplant',
    sort: has(b, 'sort') ? (parseInt(b.sort, 10) || 0) : old.sort ?? 0,
    start_date: has(b, 'start_date') ? dateOrNull(b.start_date) : old.start_date ?? null,
    end_date: has(b, 'end_date') ? dateOrNull(b.end_date) : old.end_date ?? null,
    goal: has(b, 'goal') ? str(b.goal, 1000) : old.goal ?? '',
    owner_id: has(b, 'owner_id') ? idOrNull(b.owner_id) : old.owner_id ?? null,
    public: has(b, 'public') ? (b.public && b.public !== 'false' && b.public !== '0' ? 1 : 0) : old.public ?? 0
  };
  if (!m.title || len(m.title) < 2) throw new HttpError('Gib dem Meilenstein einen Namen.');
  if (m.start_date && m.end_date && m.end_date < m.start_date) throw new HttpError('Das Ende liegt vor dem Start.');
  return m;
}
async function createMilestone({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, m = msFields(await readBody(request));
  if (!m.sort) m.sort = ((await db.prepare('SELECT MAX(sort) AS s FROM dev_milestones').first())?.s || 0) + 1;
  const r = await db.prepare('INSERT INTO dev_milestones (title, body, target, status, sort, created_at, start_date, end_date, goal, owner_id, public) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(m.title, m.body, m.target || null, m.status, m.sort, now(), m.start_date, m.end_date, m.goal, m.owner_id, m.public).run();
  await act(db, me, 'dev', 'milestone', r.meta.last_row_id, `hat den Meilenstein ${q(m.title)} angelegt`).run();
  return json({ ok: true, id: r.meta.last_row_id }, 201);
}
async function updateMilestone({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB;
  const old = await db.prepare('SELECT * FROM dev_milestones WHERE id = ?').bind(Number(params.id)).first();
  if (!old) throw new HttpError('Diesen Meilenstein gibt es nicht mehr.', 404);
  const m = msFields(await readBody(request), old);
  await db.batch([
    db.prepare('UPDATE dev_milestones SET title = ?, body = ?, target = ?, status = ?, sort = ?, start_date = ?, end_date = ?, goal = ?, owner_id = ?, public = ? WHERE id = ?').bind(m.title, m.body, m.target || null, m.status, m.sort, m.start_date, m.end_date, m.goal, m.owner_id, m.public, old.id),
    act(db, me, 'dev', 'milestone', old.id, m.status !== old.status && m.status === 'fertig' ? `hat den Meilenstein ${q(m.title)} abgeschlossen 🎉` : `hat den Meilenstein ${q(m.title)} bearbeitet`)
  ]);
  return json({ ok: true });
}
async function deleteMilestone({ request, env, params }) {
  const me = await requireAdmin(request, env, true);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT title FROM dev_milestones WHERE id = ?').bind(id).first();
  if (!old) return json({ ok: true });
  await db.batch([db.prepare('UPDATE dev_tasks SET milestone_id = NULL WHERE milestone_id = ?').bind(id), db.prepare('DELETE FROM dev_milestones WHERE id = ?').bind(id), act(db, me, 'dev', 'milestone', id, `hat den Meilenstein ${q(old.title)} gelöscht`)]);
  return json({ ok: true });
}

// Öffentliche Roadmap für die Website: nur Meilensteine mit „Auf der Website zeigen“, ohne interne Aufgaben
async function getPublicRoadmap({ env }) {
  const db = env.DB; await ensureSchema(db);
  const rows = await all(db.prepare(`SELECT m.id, m.title, m.body, m.goal, m.target, m.status, m.start_date, m.end_date,
      (SELECT COUNT(*) FROM dev_tasks t WHERE t.milestone_id = m.id) AS total,
      (SELECT COUNT(*) FROM dev_tasks t WHERE t.milestone_id = m.id AND t.status = 'fertig') AS done
    FROM dev_milestones m WHERE m.public = 1 ORDER BY m.sort, m.start_date IS NULL, m.start_date, m.id`));
  return new Response(JSON.stringify({ rows }), { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=60' } });
}

// ---------------------------------------------------------------- Dev: Scripts / Ressourcen
const RES_STATUS = ['aktiv', 'test', 'geplant', 'aus'];
const RES_KIND = ['ESX', 'Standalone', 'Eigenes Script', 'Map / MLO', 'Fahrzeug', 'Kleidung', 'UI', 'Sonstiges'];
async function listResources({ request, env }) {
  await requireAdmin(request, env);
  return json({ rows: await all(env.DB.prepare('SELECT r.*, a.name AS admin_name FROM dev_resources r LEFT JOIN admins a ON a.id = r.admin_id ORDER BY LOWER(r.name)')), statuses: RES_STATUS, kinds: RES_KIND });
}
function resFields(b, old = {}) {
  const r = {
    name: has(b, 'name') ? str(b.name, 80) : old.name,
    version: has(b, 'version') ? str(b.version, 30) : old.version ?? '',
    kind: has(b, 'kind') ? pick(b.kind, RES_KIND, 'Sonstiges') : old.kind ?? 'Sonstiges',
    status: has(b, 'status') ? pick(b.status, RES_STATUS, 'aktiv') : old.status ?? 'aktiv',
    source: has(b, 'source') ? str(b.source, 300) : old.source ?? '',
    notes: has(b, 'notes') ? str(b.notes, 3000) : old.notes ?? ''
  };
  if (len(r.name) < 2) throw new HttpError('Gib den Ressourcen-Namen an, z. B. esx_garage.');
  return r;
}
async function createResource({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, r = resFields(await readBody(request));
  const res = await db.prepare('INSERT INTO dev_resources (name, version, kind, status, source, notes, admin_id, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').bind(r.name, r.version, r.kind, r.status, r.source, r.notes, me.id, now()).run();
  await act(db, me, 'dev', 'resource', res.meta.last_row_id, `hat das Script ${q(r.name)} eingetragen`).run();
  return json({ ok: true }, 201);
}
async function updateResource({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT * FROM dev_resources WHERE id = ?').bind(id).first();
  if (!old) throw new HttpError('Dieses Script gibt es nicht mehr.', 404);
  const r = resFields(await readBody(request), old);
  await db.batch([
    db.prepare('UPDATE dev_resources SET name = ?, version = ?, kind = ?, status = ?, source = ?, notes = ?, admin_id = ?, updated_at = ? WHERE id = ?').bind(r.name, r.version, r.kind, r.status, r.source, r.notes, me.id, now(), id),
    act(db, me, 'dev', 'resource', id, r.status !== old.status ? `hat ${q(r.name)} auf „${r.status}“ gesetzt` : `hat das Script ${q(r.name)} bearbeitet`)
  ]);
  return json({ ok: true });
}
async function deleteResource({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT name FROM dev_resources WHERE id = ?').bind(id).first();
  if (!old) return json({ ok: true });
  await db.batch([db.prepare('DELETE FROM dev_resources WHERE id = ?').bind(id), act(db, me, 'dev', 'resource', id, `hat das Script ${q(old.name)} entfernt`)]);
  return json({ ok: true });
}

// ---------------------------------------------------------------- Dev: Wiki
async function listDocs({ request, env }) {
  await requireAdmin(request, env);
  return json({ rows: await all(env.DB.prepare('SELECT d.*, a.name AS admin_name FROM dev_docs d LEFT JOIN admins a ON a.id = d.admin_id ORDER BY LOWER(COALESCE(d.category, \'\')), LOWER(d.title)')) });
}
function docFields(b, old = {}) {
  const d = {
    title: has(b, 'title') ? str(b.title, 100) : old.title,
    category: has(b, 'category') ? str(b.category, 40) : old.category ?? '',
    body: has(b, 'body') ? str(b.body, 30000) : old.body ?? ''
  };
  if (len(d.title) < 2) throw new HttpError('Gib der Seite einen Titel.');
  return d;
}
async function createDoc({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, d = docFields(await readBody(request));
  const r = await db.prepare('INSERT INTO dev_docs (title, category, body, admin_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)').bind(d.title, d.category, d.body, me.id, now(), now()).run();
  await act(db, me, 'dev', 'doc', r.meta.last_row_id, `hat die Wiki-Seite ${q(d.title)} angelegt`).run();
  return json({ ok: true, id: r.meta.last_row_id }, 201);
}
async function updateDoc({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT * FROM dev_docs WHERE id = ?').bind(id).first();
  if (!old) throw new HttpError('Diese Wiki-Seite gibt es nicht mehr.', 404);
  const d = docFields(await readBody(request), old);
  await db.batch([
    db.prepare('UPDATE dev_docs SET title = ?, category = ?, body = ?, admin_id = ?, updated_at = ? WHERE id = ?').bind(d.title, d.category, d.body, me.id, now(), id),
    act(db, me, 'dev', 'doc', id, `hat die Wiki-Seite ${q(d.title)} bearbeitet`)
  ]);
  return json({ ok: true });
}
async function deleteDoc({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT title FROM dev_docs WHERE id = ?').bind(id).first();
  if (!old) return json({ ok: true });
  await db.batch([db.prepare('DELETE FROM dev_docs WHERE id = ?').bind(id), act(db, me, 'dev', 'doc', id, `hat die Wiki-Seite ${q(old.title)} gelöscht`)]);
  return json({ ok: true });
}

// ---------------------------------------------------------------- Launcher-Steuerung
// Der Launcher lädt GET /api/launcher und überschreibt damit seine eingebauten Werte.
// Nur Felder, die hier gesetzt sind, werden überschrieben.
const NEWS_COLORS = { 'Ankündigung': '#ff4fb3', 'Update': '#7aa8ff', 'Event': '#ffc04f', 'Team': '#b47cff', 'Changelog': '#4fe0a0', 'Release': '#ff7a45', 'Launcher': '#4fe0a0', 'Wartung': '#ff5a6e' };
const NOTICE_STYLES = ['info', 'warn', 'bad', 'ok'];
const LAUNCHER_IMAGES = ['', 'gallery/01-late-night-ride.jpg', 'gallery/02-sunset.jpg', 'gallery/03-low-and-slow.jpg', 'gallery/04-neon-glow.jpg', 'gallery/05-street-livery.jpg'];
const LAUNCHER_DEFAULT = {
  locked: true, releaseDate: null, serverCode: 'qqabgvz', connect: '', discord: 'https://discord.gg/q9kBzXP9va', website: '',
  notice: { text: '', style: 'info', link: '' }, newsSource: 'launcher', news: [],
  team: [], changelog: [], gallery: [], rulesSource: 'website', discordAppId: '', banCheck: true,
  download: { url: 'https://www.dropbox.com/scl/fi/jlrknch6vuxjc01t0plbf/Real-Life-Southland-Setup-1.6.0.exe?rlkey=1azaxh4ahkkrcyo0ovikppefw&st=sejctbcj&dl=1', version: '1.6.0', size: '', sha256: '' }, updated_at: null, updated_by: null
};
async function getLauncherSettings(db) {
  const row = await db.prepare("SELECT value FROM settings WHERE key = 'launcher'").first();
  let s = {}; try { s = row ? JSON.parse(row.value) : {}; } catch {}
  return { ...LAUNCHER_DEFAULT, ...s, notice: { ...LAUNCHER_DEFAULT.notice, ...(s.notice || {}) }, download: { ...LAUNCHER_DEFAULT.download, ...(s.download || {}) } };
}
const deDate = (iso) => { const d = new Date(iso); return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`; };

async function getPublicLauncher({ env, url }) {
  const db = env.DB; await ensureSchema(db);
  const s = await getLauncherSettings(db);
  const out = { locked: !!s.locked, releaseDate: s.releaseDate || null, serverCode: s.serverCode, connect: s.connect || null, discord: s.discord };
  if (s.website) out.website = s.website;
  else out.website = env.SITE_URL ? env.SITE_URL.replace(/\/$/, '') + '/' : url.origin + '/';
  out.download = { url: s.download.url || null, version: s.download.version || null, size: s.download.size || null, sha256: s.download.sha256 || null };
  out.notice = s.notice.text ? { text: s.notice.text, style: s.notice.style, link: s.notice.link || null } : null;
  if (s.newsSource === 'website') {
    const rows = await all(db.prepare('SELECT title, body, tag, created_at FROM news WHERE published = 1 ORDER BY pinned DESC, id DESC LIMIT 6'));
    if (rows.length) out.news = rows.map((n, i) => ({
      tag: n.tag, color: NEWS_COLORS[n.tag] || '#ff4fb3', date: deDate(n.created_at), title: n.title,
      text: String(n.body || '').split('\n').map((l) => l.replace(/^\s*[-*]\s+/, '• ').trim()).filter(Boolean).join('  '),
      ...(i === 0 ? { image: 'gallery/01-late-night-ride.jpg' } : {})
    }));
  } else if (s.news.length) out.news = s.news;
  if (s.team.length) out.team = s.team;
  if (s.changelog.length) out.changelog = s.changelog;
  if (s.gallery.length) out.gallery = s.gallery;
  if (s.rulesSource === 'website') {
    const row = await db.prepare('SELECT data FROM rules_versions ORDER BY id DESC LIMIT 1').first().catch(() => null);
    const rd = row ? parseJson(row.data, null) : null;
    if (rd && Array.isArray(rd.chapters) && rd.chapters.length) out.rules = rd.chapters.filter((c) => c.rules && c.rules.length).map((c) => ({ title: c.title || 'Regeln', items: c.rules.map((r) => [r.title || '', r.text || '']) }));
  }
  if (s.discordAppId) out.discordAppId = s.discordAppId;
  out.banCheck = s.banCheck !== false;
  if (Array.isArray(s.tips) && s.tips.length) out.tips = s.tips;
  return new Response(JSON.stringify(out, null, 2), { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-cache', 'Access-Control-Allow-Origin': '*' } });
}

// Launcher fragt mit der Discord-ID nach, ob der Spieler gebannt ist (ID kommt vom lokalen Discord)
async function launcherBanCheck({ env, url }) {
  const db = env.DB; await ensureSchema(db);
  const dc = String(url.searchParams.get('discord') || '').replace(/\D/g, '').slice(0, 22);
  const head = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' };
  if (dc.length < 15) return new Response(JSON.stringify({ banned: false }), { headers: head });
  const p = await db.prepare("SELECT id FROM players WHERE discord = ? OR discord = 'discord:' || ? LIMIT 1").bind(dc, dc).first();
  const s = p ? await db.prepare("SELECT type, reason, expires_at FROM sanctions WHERE player_id = ? AND type IN ('ban','permaban') AND active = 1 AND (expires_at IS NULL OR expires_at > ?) ORDER BY expires_at IS NULL DESC, expires_at DESC LIMIT 1").bind(p.id, now()).first() : null;
  const set = await getLauncherSettings(db);
  const out = s ? { banned: true, permanent: s.type === 'permaban' || !s.expires_at, reason: s.reason, until: s.expires_at, discord: set.discord } : { banned: false };
  return new Response(JSON.stringify(out), { headers: head });
}

async function getLauncherAdmin({ request, env }) {
  await requireAdmin(request, env);
  const s = await getLauncherSettings(env.DB);
  let by = null;
  if (s.updated_by) by = (await env.DB.prepare('SELECT name FROM admins WHERE id = ?').bind(s.updated_by).first())?.name || null;
  return json({ settings: s, updated_by_name: by, images: LAUNCHER_IMAGES, tags: Object.keys(NEWS_COLORS), colors: NEWS_COLORS });
}

async function saveLauncher({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, b = await readBody(request), old = await getLauncherSettings(db);
  const urlOk = (v) => { v = str(v, 300); if (v && !/^https:\/\/\S+$/.test(v)) throw new HttpError('Links müssen mit https:// anfangen.'); return v; };
  let releaseDate = null;
  if (b.releaseDate) { const d = new Date(b.releaseDate); if (isNaN(d)) throw new HttpError('Das Release-Datum ist ungültig.'); releaseDate = d.toISOString(); }
  const news = (Array.isArray(b.news) ? b.news : []).slice(0, 12).map((n) => {
    const tag = str(n.tag, 30) || 'Ankündigung';
    const item = { tag, color: /^#[0-9a-f]{6}$/i.test(n.color || '') ? n.color : (NEWS_COLORS[tag] || '#ff4fb3'), date: str(n.date, 30), title: str(n.title, 120), text: str(n.text, 1500) };
    if (LAUNCHER_IMAGES.includes(n.image) && n.image) item.image = n.image;
    return item;
  }).filter((n) => n.title);
  const s = {
    locked: !!b.locked, releaseDate,
    serverCode: str(b.serverCode, 20).replace(/[^a-z0-9]/gi, '') || old.serverCode,
    connect: str(b.connect, 80), discord: urlOk(b.discord), website: urlOk(b.website),
    notice: { text: str(b.notice?.text, 200), style: pick(b.notice?.style, NOTICE_STYLES, 'info'), link: urlOk(b.notice?.link) },
    newsSource: b.newsSource === 'website' ? 'website' : 'launcher', news,
    team: (Array.isArray(b.team) ? b.team : []).slice(0, 40).map((m) => { const o = { name: str(m.name, 40), role: str(m.role, 60) }; const a = str(m.avatar, 300); if (a && /^https:\/\/\S+$/.test(a)) o.avatar = a; return o; }).filter((m) => m.name),
    changelog: (Array.isArray(b.changelog) ? b.changelog : []).slice(0, 40).map((c) => ({
      version: str(c.version, 30), type: c.type === 'server' ? 'server' : 'launcher', date: str(c.date, 30), title: str(c.title, 120),
      changes: (Array.isArray(c.changes) ? c.changes : []).slice(0, 30).map((x) => [pick(Array.isArray(x) ? x[0] : '', ['neu', 'fix', 'änderung'], 'neu'), str(Array.isArray(x) ? x[1] : x, 300)]).filter((x) => x[1])
    })).filter((c) => c.title || c.version),
    gallery: (Array.isArray(b.gallery) ? b.gallery : []).slice(0, 40).map((g) => ({ file: urlOk(g.file), title: str(g.title, 80), big: !!g.big })).filter((g) => g.file),
    rulesSource: b.rulesSource === 'launcher' ? 'launcher' : 'website',
    discordAppId: (() => { const v = str(b.discordAppId, 25).trim(); if (v && !/^\d{15,22}$/.test(v)) throw new HttpError('Die Discord Application ID besteht nur aus Ziffern (17–20 Stellen).'); return v; })(),
    banCheck: b.banCheck !== false,
    tips: (Array.isArray(b.tips) ? b.tips : String(b.tips || '').split('\n')).map((t) => str(t, 160)).filter(Boolean).slice(0, 30),
    download: {
      url: urlOk(b.download?.url).replace(/([?&])dl=0(&|$)/, '$1dl=1$2'),
      version: str(b.download?.version, 20), size: str(b.download?.size, 20),
      sha256: (() => { const h = str(b.download?.sha256, 80).toLowerCase(); if (h && !/^[0-9a-f]{64}$/.test(h)) throw new HttpError('Die SHA-256-Prüfsumme muss 64 Zeichen lang sein (0–9, a–f).'); return h; })()
    },
    updated_at: now(), updated_by: me.id
  };
  const changes = [];
  if (s.locked !== old.locked) changes.push(s.locked ? 'Spielen gesperrt' : 'Spielen freigegeben');
  if (s.releaseDate !== old.releaseDate) changes.push(s.releaseDate ? 'Release-Datum gesetzt' : 'Release-Datum entfernt');
  if (s.notice.text !== old.notice.text) changes.push(s.notice.text ? 'Hinweis geändert' : 'Hinweis entfernt');
  if (JSON.stringify(s.news) !== JSON.stringify(old.news) || s.newsSource !== old.newsSource) changes.push('News geändert');
  if (JSON.stringify(s.team) !== JSON.stringify(old.team)) changes.push('Team geändert');
  if (JSON.stringify(s.changelog) !== JSON.stringify(old.changelog)) changes.push('Changelog geändert');
  if (JSON.stringify(s.gallery) !== JSON.stringify(old.gallery)) changes.push('Galerie geändert');
  if (s.download.url !== old.download.url || s.download.version !== old.download.version) changes.push(`Download auf Version ${s.download.version || '?'} gesetzt`);
  await db.batch([
    db.prepare("INSERT INTO settings (key, value) VALUES ('launcher', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").bind(JSON.stringify(s)),
    act(db, me, 'team', 'launcher', null, `hat den Launcher geändert${changes.length ? ': ' + changes.join(', ') : ''}`)
  ]);
  return json({ ok: true });
}

// ---------------------------------------------------------------- Team-Management
// Teamakten, Kalender & Besprechungen, Abwesenheiten, Abstimmungen, Textbausteine, Statistik
const TEAM_SCHEMA = [
  `CREATE TABLE IF NOT EXISTS team_profiles (admin_id INTEGER PRIMARY KEY, rank TEXT, area TEXT, discord TEXT, joined TEXT, probation_until TEXT, bio TEXT, onboarding TEXT, updated_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS team_records (id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER NOT NULL, kind TEXT NOT NULL, text TEXT NOT NULL, by_id INTEGER, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'meeting', starts_at TEXT NOT NULL, ends_at TEXT, location TEXT, body TEXT, protocol TEXT, created_by INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS event_rsvp (event_id INTEGER NOT NULL, admin_id INTEGER NOT NULL, status TEXT NOT NULL, PRIMARY KEY (event_id, admin_id))`,
  `CREATE TABLE IF NOT EXISTS absences (id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER NOT NULL, from_date TEXT NOT NULL, to_date TEXT NOT NULL, reason TEXT, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS polls (id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, body TEXT, options TEXT NOT NULL, anonymous INTEGER NOT NULL DEFAULT 0, closes_at TEXT, closed INTEGER NOT NULL DEFAULT 0, created_by INTEGER, created_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS poll_votes (poll_id INTEGER NOT NULL, admin_id INTEGER NOT NULL, option INTEGER NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY (poll_id, admin_id))`,
  `CREATE TABLE IF NOT EXISTS snippets (id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT, title TEXT NOT NULL, body TEXT NOT NULL, uses INTEGER NOT NULL DEFAULT 0, admin_id INTEGER, updated_at TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_events_start ON events(starts_at)`,
  `CREATE INDEX IF NOT EXISTS idx_absences_to ON absences(to_date)`,
  `CREATE INDEX IF NOT EXISTS idx_activity_admin ON activity(admin_id, created_at)`
];
PANEL_SCHEMA.push(...TEAM_SCHEMA);

const RANKS = ['Projektinhaber', 'Projektleitung', 'Stv. Projektleitung', 'Head-Admin', 'Admin', 'Moderator', 'Supporter', 'Test-Supporter', 'Developer', 'Mapper', 'Eventmanager', 'Social Media'];
const AREAS = ['Leitung', 'Support', 'Moderation', 'Entwicklung', 'Mapping', 'Events', 'Fraktionsbetreuung', 'Social Media'];
const ONBOARDING = ['Regelwerk gelesen und verstanden', 'Discord-Rollen erhalten', 'txAdmin-Zugang eingerichtet', 'Panel-Einweisung bekommen', 'Erstes Ticket begleitet', 'Sanktions-Richtlinien besprochen', 'Probezeit-Gespräch geführt'];
const RECORD_KINDS = ['lob', 'hinweis', 'verwarnung'];
const RECORD_LABEL = { lob: 'Lob', hinweis: 'Hinweis', verwarnung: 'Team-Verwarnung' };
const EVENT_KINDS = ['meeting', 'event', 'schulung', 'wartung', 'release', 'sonstiges'];
const EVENT_LABEL = { meeting: 'Teammeeting', event: 'Server-Event', schulung: 'Schulung', wartung: 'Wartung', release: 'Release', sonstiges: 'Sonstiges' };
const RSVP = ['ja', 'vielleicht', 'nein'];
const isoOrNull = (v) => { if (!v) return null; const d = new Date(v); if (isNaN(d)) throw new HttpError('Ungültiges Datum.'); return d.toISOString(); };
const canManage = (me, ownerId) => me.role === 'owner' || me.id === ownerId;

// ---------- Teamliste & Teamakten
async function getTeamList({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, today = now().slice(0, 10), since = isoAgo(30 * 864e5);
  const rows = await all(db.prepare(`SELECT a.id, a.name, a.role, a.active, a.last_login, a.created_at, p.rank, p.area, p.discord, p.joined, p.probation_until, p.bio, p.onboarding,
      (SELECT COUNT(*) FROM activity v WHERE v.admin_id = a.id AND v.created_at > ?) AS actions30,
      (SELECT MAX(v.created_at) FROM activity v WHERE v.admin_id = a.id) AS last_action,
      (SELECT x.to_date || '|' || COALESCE(x.reason, '') FROM absences x WHERE x.admin_id = a.id AND x.from_date <= ? AND x.to_date >= ? ORDER BY x.to_date DESC LIMIT 1) AS away,
      (SELECT COUNT(*) FROM team_records r WHERE r.admin_id = a.id AND r.kind = 'verwarnung') AS warns,
      (SELECT COUNT(*) FROM team_records r WHERE r.admin_id = a.id AND r.kind = 'lob') AS praise
    FROM admins a LEFT JOIN team_profiles p ON p.admin_id = a.id ORDER BY a.active DESC, a.name`).bind(since, today, today));
  const out = rows.map((r) => {
    let ob = {}; try { ob = JSON.parse(r.onboarding || '{}'); } catch {}
    const o = { ...r, onboarding: ob, away: r.away ? { until: r.away.split('|')[0], reason: r.away.split('|').slice(1).join('|') } : null };
    if (me.role !== 'owner' && me.id !== r.id) { delete o.warns; delete o.praise; }
    return o;
  });
  return json({ rows: out, ranks: RANKS, areas: AREAS, onboardingItems: ONBOARDING });
}

async function getTeamMember({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const a = await db.prepare('SELECT a.id, a.name, a.role, a.active, a.last_login, a.created_at, p.* FROM admins a LEFT JOIN team_profiles p ON p.admin_id = a.id WHERE a.id = ?').bind(id).first();
  if (!a) throw new HttpError('Dieses Teammitglied gibt es nicht.', 404);
  a.id = id; let ob = {}; try { ob = JSON.parse(a.onboarding || '{}'); } catch {} a.onboarding = ob;
  const mayRecords = me.role === 'owner' || me.id === id;
  const [records, recent, absences, kinds] = await Promise.all([
    mayRecords ? all(db.prepare('SELECT r.*, b.name AS by_name FROM team_records r LEFT JOIN admins b ON b.id = r.by_id WHERE r.admin_id = ? ORDER BY r.id DESC').bind(id)) : [],
    all(db.prepare('SELECT * FROM activity WHERE admin_id = ? ORDER BY id DESC LIMIT 15').bind(id)),
    all(db.prepare('SELECT * FROM absences WHERE admin_id = ? AND to_date >= ? ORDER BY from_date').bind(id, now().slice(0, 10))),
    all(db.prepare('SELECT kind, COUNT(*) AS n FROM activity WHERE admin_id = ? AND created_at > ? GROUP BY kind').bind(id, isoAgo(30 * 864e5)))
  ]);
  return json({ member: a, records, recent, absences, kinds, mayRecords, ranks: RANKS, areas: AREAS, onboardingItems: ONBOARDING });
}

async function saveTeamProfile({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id), b = await readBody(request);
  const t = await db.prepare('SELECT name FROM admins WHERE id = ?').bind(id).first();
  if (!t) throw new HttpError('Dieses Teammitglied gibt es nicht.', 404);
  const old = (await db.prepare('SELECT * FROM team_profiles WHERE admin_id = ?').bind(id).first()) || {};
  const owner = me.role === 'owner';
  if (!owner && me.id !== id) throw new HttpError('Fremde Profile ändert nur die Projektleitung.', 403);
  const p = {
    discord: has(b, 'discord') ? str(b.discord, 60) : old.discord ?? '',
    bio: has(b, 'bio') ? str(b.bio, 1000) : old.bio ?? '',
    rank: old.rank ?? '', area: old.area ?? '', joined: old.joined ?? null, probation_until: old.probation_until ?? null, onboarding: old.onboarding ?? '{}'
  };
  const restricted = ['rank', 'area', 'joined', 'probation_until', 'onboarding'].filter((k) => has(b, k));
  if (restricted.length && !owner) throw new HttpError('Rang, Bereich, Probezeit und Einarbeitung ändert nur die Projektleitung.', 403);
  if (has(b, 'rank')) p.rank = str(b.rank, 40);
  if (has(b, 'area')) p.area = str(b.area, 40);
  if (has(b, 'joined')) p.joined = dateOrNull(b.joined);
  if (has(b, 'probation_until')) p.probation_until = dateOrNull(b.probation_until);
  if (has(b, 'onboarding')) { const o = {}; for (const k of ONBOARDING) if (b.onboarding && b.onboarding[k]) o[k] = true; p.onboarding = JSON.stringify(o); }
  const text = has(b, 'onboarding') && Object.keys(b).length === 1 ? `hat die Einarbeitung von ${q(t.name)} aktualisiert`
    : has(b, 'rank') && p.rank !== old.rank ? `hat ${q(t.name)} den Rang „${p.rank || '–'}“ gegeben` : me.id === id ? 'hat sein Team-Profil bearbeitet' : `hat das Profil von ${q(t.name)} bearbeitet`;
  await db.batch([
    db.prepare(`INSERT INTO team_profiles (admin_id, rank, area, discord, joined, probation_until, bio, onboarding, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(admin_id) DO UPDATE SET rank = excluded.rank, area = excluded.area, discord = excluded.discord, joined = excluded.joined, probation_until = excluded.probation_until, bio = excluded.bio, onboarding = excluded.onboarding, updated_at = excluded.updated_at`)
      .bind(id, p.rank, p.area, p.discord, p.joined, p.probation_until, p.bio, p.onboarding, now()),
    act(db, me, 'team', 'profile', id, text)
  ]);
  return json({ ok: true });
}

async function addTeamRecord({ request, env, params, ctx }) {
  const me = await requireAdmin(request, env, true);
  const db = env.DB, id = Number(params.id), b = await readBody(request);
  const t = await db.prepare('SELECT name FROM admins WHERE id = ?').bind(id).first();
  if (!t) throw new HttpError('Dieses Teammitglied gibt es nicht.', 404);
  const kind = pick(b.kind, RECORD_KINDS, ''), text = str(b.text, 1500);
  if (!kind) throw new HttpError('Wähl die Art des Eintrags.');
  if (len(text) < 3) throw new HttpError('Schreib kurz, worum es geht.');
  await db.batch([
    db.prepare('INSERT INTO team_records (admin_id, kind, text, by_id, created_at) VALUES (?, ?, ?, ?, ?)').bind(id, kind, text, me.id, now()),
    act(db, me, 'team', 'profile', id, kind === 'lob' ? `hat ${q(t.name)} gelobt 🌟` : 'hat etwas in einer Teamakte vermerkt')
  ]);
  return json({ ok: true }, 201);
}
async function deleteTeamRecord({ request, env, params }) {
  const me = await requireAdmin(request, env, true);
  const db = env.DB, id = Number(params.id);
  const r = await db.prepare('SELECT r.admin_id, a.name FROM team_records r JOIN admins a ON a.id = r.admin_id WHERE r.id = ?').bind(id).first();
  if (!r) return json({ ok: true });
  await db.batch([db.prepare('DELETE FROM team_records WHERE id = ?').bind(id), act(db, me, 'team', 'profile', r.admin_id, `hat einen Eintrag aus der Teamakte von ${q(r.name)} entfernt`)]);
  return json({ ok: true });
}

// ---------- Kalender & Besprechungen
async function listEvents({ request, env, url }) {
  const me = await requireAdmin(request, env);
  const db = env.DB;
  const from = isoOrNull(url.searchParams.get('from')) || isoAgo(40 * 864e5);
  const to = isoOrNull(url.searchParams.get('to')) || new Date(Date.now() + 120 * 864e5).toISOString();
  const [events, rsvps, absences, team] = await Promise.all([
    all(db.prepare('SELECT e.*, c.name AS created_by_name FROM events e LEFT JOIN admins c ON c.id = e.created_by WHERE e.starts_at >= ? AND e.starts_at <= ? ORDER BY e.starts_at').bind(from, to)),
    all(db.prepare('SELECT r.event_id, r.admin_id, r.status, a.name FROM event_rsvp r JOIN admins a ON a.id = r.admin_id WHERE r.event_id IN (SELECT id FROM events WHERE starts_at >= ? AND starts_at <= ?)').bind(from, to)),
    all(db.prepare('SELECT x.*, a.name FROM absences x JOIN admins a ON a.id = x.admin_id WHERE x.to_date >= ? AND x.from_date <= ? ORDER BY x.from_date').bind(from.slice(0, 10), to.slice(0, 10))),
    all(db.prepare('SELECT id, name FROM admins WHERE active = 1 ORDER BY name'))
  ]);
  for (const e of events) { e.rsvp = rsvps.filter((r) => r.event_id === e.id).map(({ admin_id, status, name }) => ({ admin_id, status, name })); e.mine = e.rsvp.find((r) => r.admin_id === me.id)?.status || null; }
  return json({ events, absences, team, kinds: EVENT_LABEL });
}
function eventFields(b, old = {}) {
  const e = {
    title: has(b, 'title') ? str(b.title, 120) : old.title,
    kind: has(b, 'kind') ? pick(b.kind, EVENT_KINDS, 'meeting') : old.kind ?? 'meeting',
    starts_at: has(b, 'starts_at') ? isoOrNull(b.starts_at) : old.starts_at,
    ends_at: has(b, 'ends_at') ? isoOrNull(b.ends_at) : old.ends_at ?? null,
    location: has(b, 'location') ? str(b.location, 120) : old.location ?? '',
    body: has(b, 'body') ? str(b.body, 6000) : old.body ?? '',
    protocol: has(b, 'protocol') ? str(b.protocol, 20000) : old.protocol ?? ''
  };
  if (len(e.title) < 2) throw new HttpError('Gib dem Termin einen Titel.');
  if (!e.starts_at) throw new HttpError('Wann ist der Termin?');
  if (e.ends_at && e.ends_at < e.starts_at) throw new HttpError('Das Ende liegt vor dem Beginn.');
  return e;
}
async function createEvent({ request, env, ctx }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, e = eventFields(await readBody(request));
  const r = await db.prepare('INSERT INTO events (title, kind, starts_at, ends_at, location, body, protocol, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(e.title, e.kind, e.starts_at, e.ends_at, e.location, e.body, e.protocol, me.id, now(), now()).run();
  const id = r.meta.last_row_id;
  await db.batch([
    db.prepare("INSERT INTO event_rsvp (event_id, admin_id, status) VALUES (?, ?, 'ja')").bind(id, me.id),
    act(db, me, 'team', 'event', id, `hat den Termin ${q(e.title)} angelegt (${EVENT_LABEL[e.kind]})`)
  ]);
  const when = new Date(e.starts_at).toLocaleString('de-DE', { timeZone: 'Europe/Berlin', dateStyle: 'full', timeStyle: 'short' });
  await discordNotify(env, ctx, { title: `📅 ${EVENT_LABEL[e.kind]}: ${e.title}`, color: 0x7aa8ff, url: siteLink(env, '/admin/#kalender'), description: `**Wann:** ${when}${e.location ? `\n**Wo:** ${e.location}` : ''}\nZu- oder absagen im Team-Panel.` });
  return json({ ok: true, id }, 201);
}
async function updateEvent({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT * FROM events WHERE id = ?').bind(id).first();
  if (!old) throw new HttpError('Diesen Termin gibt es nicht mehr.', 404);
  const b = await readBody(request), e = eventFields(b, old);
  const onlyProtocol = Object.keys(b).length === 1 && has(b, 'protocol');
  await db.batch([
    db.prepare('UPDATE events SET title = ?, kind = ?, starts_at = ?, ends_at = ?, location = ?, body = ?, protocol = ?, updated_at = ? WHERE id = ?').bind(e.title, e.kind, e.starts_at, e.ends_at, e.location, e.body, e.protocol, now(), id),
    act(db, me, 'team', 'event', id, onlyProtocol ? `hat das Protokoll zu ${q(e.title)} geschrieben` : `hat den Termin ${q(e.title)} bearbeitet`)
  ]);
  return json({ ok: true });
}
async function deleteEvent({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT title, created_by FROM events WHERE id = ?').bind(id).first();
  if (!old) return json({ ok: true });
  if (!canManage(me, old.created_by)) throw new HttpError('Nur wer den Termin angelegt hat oder der Owner darf ihn löschen.', 403);
  await db.batch([db.prepare('DELETE FROM event_rsvp WHERE event_id = ?').bind(id), db.prepare('DELETE FROM events WHERE id = ?').bind(id), act(db, me, 'team', 'event', id, `hat den Termin ${q(old.title)} abgesagt`)]);
  return json({ ok: true });
}
async function rsvpEvent({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id), status = pick((await readBody(request)).status, RSVP, '');
  if (!status) throw new HttpError('Zusage, Vielleicht oder Absage?');
  const e = await db.prepare('SELECT title FROM events WHERE id = ?').bind(id).first();
  if (!e) throw new HttpError('Diesen Termin gibt es nicht mehr.', 404);
  await db.batch([
    db.prepare('INSERT INTO event_rsvp (event_id, admin_id, status) VALUES (?, ?, ?) ON CONFLICT(event_id, admin_id) DO UPDATE SET status = excluded.status').bind(id, me.id, status),
    act(db, me, 'team', 'event', id, `hat für ${q(e.title)} ${status === 'ja' ? 'zugesagt ✅' : status === 'nein' ? 'abgesagt' : 'mit „vielleicht“ geantwortet'}`)
  ]);
  return json({ ok: true });
}

// ---------- Abwesenheiten
async function createAbsence({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, b = await readBody(request);
  const from = dateOrNull(b.from_date), to = dateOrNull(b.to_date), reason = str(b.reason, 200);
  let who = me.id;
  if (b.admin_id && Number(b.admin_id) !== me.id) { if (me.role !== 'owner') throw new HttpError('Für andere trägt nur der Owner Abwesenheiten ein.', 403); who = Number(b.admin_id); }
  if (!from || !to) throw new HttpError('Von wann bis wann bist du weg?');
  if (to < from) throw new HttpError('„Bis“ liegt vor „Von“.');
  const name = (await db.prepare('SELECT name FROM admins WHERE id = ?').bind(who).first())?.name || '?';
  const r = await db.prepare('INSERT INTO absences (admin_id, from_date, to_date, reason, created_at) VALUES (?, ?, ?, ?, ?)').bind(who, from, to, reason, now()).run();
  const fmtD = (d) => d.split('-').reverse().join('.');
  await act(db, me, 'team', 'absence', r.meta.last_row_id, `${who === me.id ? 'ist abwesend' : `hat ${q(name)} als abwesend eingetragen:`} ${fmtD(from)} – ${fmtD(to)}${reason ? ' (' + reason + ')' : ''}`).run();
  return json({ ok: true }, 201);
}
async function deleteAbsence({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const x = await db.prepare('SELECT * FROM absences WHERE id = ?').bind(id).first();
  if (!x) return json({ ok: true });
  if (!canManage(me, x.admin_id)) throw new HttpError('Das darf nur die Person selbst oder der Owner.', 403);
  await db.batch([db.prepare('DELETE FROM absences WHERE id = ?').bind(id), act(db, me, 'team', 'absence', id, 'hat eine Abwesenheit gelöscht')]);
  return json({ ok: true });
}

// ---------- Abstimmungen
async function listPolls({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB;
  const [polls, votes, team] = await Promise.all([
    all(db.prepare('SELECT p.*, c.name AS created_by_name FROM polls p LEFT JOIN admins c ON c.id = p.created_by ORDER BY (p.closed = 0 AND (p.closes_at IS NULL OR p.closes_at > ?)) DESC, p.id DESC LIMIT 60').bind(now())),
    all(db.prepare('SELECT v.poll_id, v.admin_id, v.option, a.name FROM poll_votes v JOIN admins a ON a.id = v.admin_id')),
    db.prepare('SELECT COUNT(*) AS n FROM admins WHERE active = 1').first()
  ]);
  const n = now();
  const rows = polls.map((p) => {
    let options = []; try { options = JSON.parse(p.options); } catch {}
    const vs = votes.filter((v) => v.poll_id === p.id);
    const open = !p.closed && (!p.closes_at || p.closes_at > n);
    return {
      ...p, options, open, total: vs.length, teamSize: team.n,
      counts: options.map((_, i) => vs.filter((v) => v.option === i).length),
      voters: p.anonymous ? null : options.map((_, i) => vs.filter((v) => v.option === i).map((v) => v.name)),
      mine: vs.find((v) => v.admin_id === me.id)?.option ?? null
    };
  });
  return json({ rows });
}
async function createPoll({ request, env, ctx }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, b = await readBody(request);
  const question = str(b.question, 200), body = str(b.body, 2000);
  const options = (Array.isArray(b.options) ? b.options : []).map((o) => str(o, 100)).filter(Boolean).slice(0, 10);
  if (len(question) < 3) throw new HttpError('Wie lautet die Frage?');
  if (options.length < 2) throw new HttpError('Eine Abstimmung braucht mindestens zwei Antworten.');
  if (new Set(options.map((o) => o.toLowerCase())).size !== options.length) throw new HttpError('Jede Antwort darf nur einmal vorkommen.');
  const closes = isoOrNull(b.closes_at);
  const r = await db.prepare('INSERT INTO polls (question, body, options, anonymous, closes_at, closed, created_by, created_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?)')
    .bind(question, body, JSON.stringify(options), b.anonymous ? 1 : 0, closes, me.id, now()).run();
  await act(db, me, 'team', 'poll', r.meta.last_row_id, `hat eine Abstimmung gestartet: ${q(question)}`).run();
  await discordNotify(env, ctx, { title: `🗳️ Neue Abstimmung: ${question}`, color: 0xb47cff, url: siteLink(env, '/admin/#abstimmungen'), description: options.map((o) => '• ' + o).join('\n') + '\n\nAbstimmen im Team-Panel.' });
  return json({ ok: true }, 201);
}
async function votePoll({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id), b = await readBody(request);
  const p = await db.prepare('SELECT * FROM polls WHERE id = ?').bind(id).first();
  if (!p) throw new HttpError('Diese Abstimmung gibt es nicht mehr.', 404);
  if (p.closed || (p.closes_at && p.closes_at <= now())) throw new HttpError('Diese Abstimmung ist schon beendet.');
  const n = JSON.parse(p.options).length, opt = parseInt(b.option, 10);
  if (!(opt >= 0 && opt < n)) throw new HttpError('Ungültige Antwort.');
  await db.batch([
    db.prepare('INSERT INTO poll_votes (poll_id, admin_id, option, created_at) VALUES (?, ?, ?, ?) ON CONFLICT(poll_id, admin_id) DO UPDATE SET option = excluded.option, created_at = excluded.created_at').bind(id, me.id, opt, now()),
    act(db, me, 'team', 'poll', id, `hat bei ${q(p.question)} abgestimmt`)
  ]);
  return json({ ok: true });
}
async function closePoll({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const p = await db.prepare('SELECT question, created_by FROM polls WHERE id = ?').bind(id).first();
  if (!p) throw new HttpError('Diese Abstimmung gibt es nicht mehr.', 404);
  if (!canManage(me, p.created_by)) throw new HttpError('Beenden darf nur, wer sie gestartet hat, oder der Owner.', 403);
  await db.batch([db.prepare('UPDATE polls SET closed = 1 WHERE id = ?').bind(id), act(db, me, 'team', 'poll', id, `hat die Abstimmung ${q(p.question)} beendet`)]);
  return json({ ok: true });
}
async function deletePoll({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const p = await db.prepare('SELECT question, created_by FROM polls WHERE id = ?').bind(id).first();
  if (!p) return json({ ok: true });
  if (!canManage(me, p.created_by)) throw new HttpError('Löschen darf nur, wer sie gestartet hat, oder der Owner.', 403);
  await db.batch([db.prepare('DELETE FROM poll_votes WHERE poll_id = ?').bind(id), db.prepare('DELETE FROM polls WHERE id = ?').bind(id), act(db, me, 'team', 'poll', id, `hat die Abstimmung ${q(p.question)} gelöscht`)]);
  return json({ ok: true });
}

// ---------- Textbausteine
async function listSnippets({ request, env }) {
  await requireAdmin(request, env);
  return json({ rows: await all(env.DB.prepare('SELECT s.*, a.name AS admin_name FROM snippets s LEFT JOIN admins a ON a.id = s.admin_id ORDER BY LOWER(COALESCE(s.category, \'\')), s.uses DESC, LOWER(s.title)')) });
}
function snippetFields(b, old = {}) {
  const s = { category: has(b, 'category') ? str(b.category, 40) : old.category ?? '', title: has(b, 'title') ? str(b.title, 100) : old.title, body: has(b, 'body') ? str(b.body, 4000) : old.body };
  if (len(s.title) < 2) throw new HttpError('Gib dem Textbaustein einen Namen.');
  if (len(s.body) < 2) throw new HttpError('Der Text ist leer.');
  return s;
}
async function createSnippet({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, s = snippetFields(await readBody(request));
  const r = await db.prepare('INSERT INTO snippets (category, title, body, uses, admin_id, updated_at) VALUES (?, ?, ?, 0, ?, ?)').bind(s.category, s.title, s.body, me.id, now()).run();
  await act(db, me, 'team', 'snippet', r.meta.last_row_id, `hat den Textbaustein ${q(s.title)} angelegt`).run();
  return json({ ok: true }, 201);
}
async function updateSnippet({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT * FROM snippets WHERE id = ?').bind(id).first();
  if (!old) throw new HttpError('Diesen Textbaustein gibt es nicht mehr.', 404);
  const s = snippetFields(await readBody(request), old);
  await db.batch([db.prepare('UPDATE snippets SET category = ?, title = ?, body = ?, admin_id = ?, updated_at = ? WHERE id = ?').bind(s.category, s.title, s.body, me.id, now(), id), act(db, me, 'team', 'snippet', id, `hat den Textbaustein ${q(s.title)} bearbeitet`)]);
  return json({ ok: true });
}
async function useSnippet({ request, env, params }) {
  await requireAdmin(request, env);
  await env.DB.prepare('UPDATE snippets SET uses = uses + 1 WHERE id = ?').bind(Number(params.id)).run();
  return json({ ok: true });
}
async function deleteSnippet({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT title FROM snippets WHERE id = ?').bind(id).first();
  if (!old) return json({ ok: true });
  await db.batch([db.prepare('DELETE FROM snippets WHERE id = ?').bind(id), act(db, me, 'team', 'snippet', id, `hat den Textbaustein ${q(old.title)} gelöscht`)]);
  return json({ ok: true });
}

// ---------- Statistik
async function getStats({ request, env, url }) {
  await requireAdmin(request, env);
  const db = env.DB, days = [7, 30, 90].includes(Number(url.searchParams.get('days'))) ? Number(url.searchParams.get('days')) : 30;
  const since = isoAgo(days * 864e5);
  const [people, byKind, daily, decided, sanctions, tasksDone, totals] = await Promise.all([
    all(db.prepare('SELECT a.id, a.name, p.rank FROM admins a LEFT JOIN team_profiles p ON p.admin_id = a.id WHERE a.active = 1 ORDER BY a.name')),
    all(db.prepare('SELECT admin_id, kind, COUNT(*) AS n FROM activity WHERE created_at > ? AND admin_id IS NOT NULL GROUP BY admin_id, kind').bind(since)),
    all(db.prepare('SELECT substr(created_at, 1, 10) AS d, COUNT(*) AS n FROM activity WHERE created_at > ? GROUP BY d ORDER BY d').bind(since)),
    all(db.prepare("SELECT decided_by AS id, COUNT(*) AS n FROM applications WHERE decided_at > ? AND status IN ('angenommen','abgelehnt') GROUP BY decided_by").bind(since)),
    all(db.prepare('SELECT admin_id AS id, COUNT(*) AS n FROM sanctions WHERE created_at > ? GROUP BY admin_id').bind(since)),
    all(db.prepare("SELECT assignee_id AS id, COUNT(*) AS n FROM dev_tasks WHERE status = 'fertig' AND updated_at > ? AND assignee_id IS NOT NULL GROUP BY assignee_id").bind(since)),
    db.prepare(`SELECT (SELECT COUNT(*) FROM activity WHERE created_at > ?1) AS actions,
      (SELECT COUNT(*) FROM applications WHERE created_at > ?1) AS apps,
      (SELECT COUNT(*) FROM sanctions WHERE created_at > ?1) AS sanctions,
      (SELECT COUNT(*) FROM dev_tasks WHERE status = 'fertig' AND updated_at > ?1) AS tasks,
      (SELECT COUNT(*) FROM events WHERE starts_at > ?1 AND starts_at <= ?2) AS events`).bind(since, now()).first()
  ]);
  const get = (arr, id) => arr.find((x) => x.id === id)?.n || 0;
  const rows = people.map((p) => {
    const kinds = Object.fromEntries(byKind.filter((k) => k.admin_id === p.id).map((k) => [k.kind, k.n]));
    return { ...p, actions: Object.values(kinds).reduce((a, b) => a + b, 0), kinds, decided: get(decided, p.id), sanctions: get(sanctions, p.id), tasks: get(tasksDone, p.id) };
  }).sort((a, b) => b.actions - a.actions);
  return json({ days, rows, daily, totals });
}

// ---------------------------------------------------------------- Regelwerk (im Panel bearbeitbar, Website lädt die neueste Version)
PANEL_SCHEMA.push(`CREATE TABLE IF NOT EXISTS rules_versions (id INTEGER PRIMARY KEY AUTOINCREMENT, data TEXT NOT NULL, note TEXT, admin_id INTEGER, created_at TEXT NOT NULL)`);
const PENALTY_COLORS = ['#4fe0a0', '#ffc04f', '#ff7a45', '#ff4f6a', '#7aa8ff', '#b47cff'];
function cleanRules(b) {
  const chapters = (Array.isArray(b.chapters) ? b.chapters : []).slice(0, 40).map((c) => ({
    title: str(c.title, 80),
    rules: (Array.isArray(c.rules) ? c.rules : []).slice(0, 80).map((r) => ({ title: str(r.title, 120), text: str(r.text, 3000) })).filter((r) => r.title || r.text)
  })).filter((c) => c.title || c.rules.length);
  if (!chapters.length) throw new HttpError('Das Regelwerk braucht mindestens ein Kapitel.');
  for (const [i, c] of chapters.entries()) {
    if (!c.title) throw new HttpError(`Kapitel ${i + 1} hat keinen Namen.`);
    for (const [j, r] of c.rules.entries()) if (!r.title || !r.text) throw new HttpError(`§ ${i + 1}.${j + 1} braucht eine Überschrift und einen Text.`);
  }
  const penalties = (Array.isArray(b.penalties) ? b.penalties : []).slice(0, 12).map((p) => ({
    label: str(p.label, 80), example: str(p.example, 200), color: PENALTY_COLORS.includes(p.color) ? p.color : PENALTY_COLORS[0]
  })).filter((p) => p.label);
  return { stand: dateOrNull(b.stand) || now().slice(0, 10), intro: str(b.intro, 600), chapters, penalties };
}
async function latestRules(db) {
  const row = await db.prepare('SELECT v.*, a.name AS admin_name FROM rules_versions v LEFT JOIN admins a ON a.id = v.admin_id ORDER BY v.id DESC LIMIT 1').first();
  if (!row) return null;
  let data = null; try { data = JSON.parse(row.data); } catch {}
  return { id: row.id, data, note: row.note, admin_name: row.admin_name, created_at: row.created_at };
}
async function getPublicRules({ env }) {
  await ensureSchema(env.DB);
  const v = await latestRules(env.DB);
  return new Response(JSON.stringify({ rules: v ? v.data : null, updated_at: v ? v.created_at : null }), { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-cache' } });
}
async function getRulesAdmin({ request, env }) {
  await requireAdmin(request, env);
  const db = env.DB;
  const versions = await all(db.prepare('SELECT v.id, v.note, v.created_at, a.name AS admin_name FROM rules_versions v LEFT JOIN admins a ON a.id = v.admin_id ORDER BY v.id DESC LIMIT 30'));
  return json({ current: await latestRules(db), versions, colors: PENALTY_COLORS, webhook: !!(await getWebhook(env, 'rules')) });
}
async function getRulesVersion({ request, env, params }) {
  await requireAdmin(request, env);
  const row = await env.DB.prepare('SELECT data FROM rules_versions WHERE id = ?').bind(Number(params.id)).first();
  if (!row) throw new HttpError('Diese Version gibt es nicht.', 404);
  return json({ data: JSON.parse(row.data) });
}
async function saveRules({ request, env, ctx }) {
  const me = await requireAdmin(request, env, true);
  const db = env.DB, b = await readBody(request);
  const data = cleanRules(b), note = str(b.note, 200);
  const prev = await latestRules(db);
  const count = data.chapters.reduce((n, c) => n + c.rules.length, 0);
  await db.batch([
    db.prepare('INSERT INTO rules_versions (data, note, admin_id, created_at) VALUES (?, ?, ?, ?)').bind(JSON.stringify(data), note, me.id, now()),
    db.prepare("DELETE FROM rules_versions WHERE id NOT IN (SELECT id FROM rules_versions ORDER BY id DESC LIMIT 50)"),
    act(db, me, 'team', 'rules', null, `hat das Regelwerk veröffentlicht (${data.chapters.length} Kapitel, ${count} Regeln)${note ? ': ' + note : ''}`)
  ]);
  let announced = null;
  if (b.announce) {
    const url = await getWebhook(env, 'rules');
    if (!url) announced = { ok: false, error: 'Kein Discord-Kanal eingetragen (Einstellungen → Discord-Kanäle).' };
    else {
      const origin = new URL(request.url).origin;
      const changes = diffRules(prev && prev.data, data);
      const list = changes.length > 15 ? [...changes.slice(0, 15), `… und ${changes.length - 15} weitere Änderungen`] : changes;
      const desc = [note ? `> ${note}` : '', list.length ? list.join('\n') : (prev ? 'Kleine Korrekturen an Formulierungen.' : 'Das Regelwerk ist jetzt online.'), '', `👉 **[Zum Regelwerk](${origin}/regelwerk.html)**`].filter((x, i) => x || i > 0).join('\n');
      announced = await sendWebhook(url, {
        username: 'Southland Regelwerk', avatar_url: origin + '/logo.png',
        embeds: [{ title: '📜 Das Regelwerk wurde aktualisiert', url: origin + '/regelwerk.html', color: 0xff4fb3, description: desc.slice(0, 4000),
          fields: [{ name: 'Stand', value: data.stand.split('-').reverse().join('.'), inline: true }, { name: 'Kapitel', value: String(data.chapters.length), inline: true }, { name: 'Regeln', value: String(count), inline: true }],
          footer: { text: 'Real Life Southland · Unwissenheit schützt nicht vor Strafe' }, timestamp: now() }]
      });
    }
  }
  return json({ ok: true, announced });
}

// ---------- Webhook-Einstellungen (nur Owner)
async function getWebhooks({ request, env }) {
  await requireAdmin(request, env, true);
  const out = {};
  for (const [k, label] of Object.entries(WEBHOOK_KINDS)) {
    const row = await env.DB.prepare('SELECT value FROM settings WHERE key = ?').bind('webhook_' + k).first();
    out[k] = { label, set: !!(row && row.value), hint: maskWebhook(row && row.value), fallback: !(row && row.value) && !!(env['DISCORD_WEBHOOK_' + k.toUpperCase()] || env.DISCORD_WEBHOOK) };
  }
  return json({ webhooks: out });
}
async function saveWebhook({ request, env, params }) {
  const me = await requireAdmin(request, env, true);
  const kind = String(params.kind || '');
  if (!WEBHOOK_KINDS[kind]) throw new HttpError('Unbekannter Kanal.', 404);
  const url = str((await readBody(request)).url, 300);
  if (url && !WEBHOOK_RE.test(url)) throw new HttpError('Das ist kein gültiger Discord-Webhook-Link. Er beginnt mit https://discord.com/api/webhooks/…');
  const db = env.DB;
  await db.batch([
    url ? db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').bind('webhook_' + kind, url)
        : db.prepare('DELETE FROM settings WHERE key = ?').bind('webhook_' + kind),
    act(db, me, 'team', 'settings', null, url ? `hat den Discord-Kanal für ${WEBHOOK_KINDS[kind]} eingerichtet` : `hat den Discord-Kanal für ${WEBHOOK_KINDS[kind]} entfernt`)
  ]);
  return json({ ok: true, hint: maskWebhook(url) });
}
async function testWebhook({ request, env, params }) {
  const me = await requireAdmin(request, env, true);
  const kind = String(params.kind || '');
  if (!WEBHOOK_KINDS[kind]) throw new HttpError('Unbekannter Kanal.', 404);
  const url = await getWebhook(env, kind);
  if (!url) throw new HttpError('Für diesen Kanal ist noch kein Webhook eingetragen.');
  const origin = new URL(request.url).origin;
  const r = await sendWebhook(url, { username: 'Southland Regelwerk', avatar_url: origin + '/logo.png', embeds: [{ title: '✅ Test erfolgreich', description: `Dieser Kanal bekommt ab jetzt die ${WEBHOOK_KINDS[kind]} von Real Life Southland.\nEingerichtet von ${me.name}.`, color: 0x4fe0a0, timestamp: now(), footer: { text: 'Real Life Southland · Team-Panel' } }] });
  if (!r.ok) throw new HttpError(r.error, 502);
  return json({ ok: true });
}

// ---------- Was hat sich am Regelwerk geändert? (für die Discord-Nachricht)
function diffRules(oldData, data) {
  const lines = [];
  const key = (t) => String(t || '').trim().toLowerCase();
  const oldMap = new Map(), newMap = new Map();
  (oldData?.chapters || []).forEach((c, i) => c.rules.forEach((r, j) => oldMap.set(key(r.title), { ...r, n: `${i + 1}.${j + 1}` })));
  data.chapters.forEach((c, i) => c.rules.forEach((r, j) => newMap.set(key(r.title), { ...r, n: `${i + 1}.${j + 1}`, ch: c.title })));
  const oldCh = new Set((oldData?.chapters || []).map((c) => key(c.title)));
  data.chapters.forEach((c, i) => { if (oldData && !oldCh.has(key(c.title))) lines.push(`📂 Neues Kapitel **${i + 1}. ${c.title}**`); });
  for (const [k, r] of newMap) {
    const o = oldMap.get(k);
    if (!o) lines.push(`🆕 **§ ${r.n} ${r.title}**`);
    else if (o.text.trim() !== r.text.trim()) lines.push(`✏️ **§ ${r.n} ${r.title}** wurde geändert`);
  }
  for (const [k, o] of oldMap) if (!newMap.has(k)) lines.push(`🗑️ ~~§ ${o.n} ${o.title}~~ wurde gestrichen`);
  if (JSON.stringify(oldData?.penalties || []) !== JSON.stringify(data.penalties) && oldData) lines.push('⚖️ Der Strafkatalog wurde angepasst');
  return lines;
}

// ---------------------------------------------------------------- Social Media (Links im Panel pflegen, Website zeigt sie)
const SOCIAL_PLATFORMS = ['discord', 'youtube', 'twitch', 'tiktok', 'instagram', 'x', 'kick'];
const SOCIAL_DEFAULT = { intro: '', platforms: { discord: { url: 'https://discord.gg/q9kBzXP9va', handle: 'Real Life Southland', text: 'Community, Support & News', show: true } }, creators: [] };
async function getSocials(db) {
  const row = await db.prepare("SELECT value FROM settings WHERE key = 'socials'").first();
  let s = null; try { s = row ? JSON.parse(row.value) : null; } catch {}
  return s || SOCIAL_DEFAULT;
}
async function getPublicSocials({ env }) {
  await ensureSchema(env.DB);
  const s = await getSocials(env.DB);
  const platforms = SOCIAL_PLATFORMS.filter((k) => s.platforms[k] && s.platforms[k].show && s.platforms[k].url).map((k) => ({ key: k, ...s.platforms[k] }));
  return new Response(JSON.stringify({ intro: s.intro || '', platforms, creators: s.creators || [] }), { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-cache' } });
}
async function getSocialsAdmin({ request, env }) {
  await requireAdmin(request, env);
  return json({ socials: await getSocials(env.DB), platforms: SOCIAL_PLATFORMS });
}
async function saveSocials({ request, env }) {
  const me = await requireAdmin(request, env);
  const b = await readBody(request), db = env.DB;
  const httpsOk = (v, what) => { v = str(v, 300); if (v && !/^https:\/\/[^\s<>"']+$/.test(v)) throw new HttpError(`${what}: Der Link muss mit https:// anfangen.`); return v; };
  const NAMES = { discord: 'Discord', youtube: 'YouTube', twitch: 'Twitch', tiktok: 'TikTok', instagram: 'Instagram', x: 'X', kick: 'Kick' };
  const platforms = {};
  for (const k of SOCIAL_PLATFORMS) {
    const p = (b.platforms || {})[k] || {};
    platforms[k] = { url: httpsOk(p.url, NAMES[k]), handle: str(p.handle, 60), text: str(p.text, 80), show: !!p.show };
  }
  const creators = (Array.isArray(b.creators) ? b.creators : []).slice(0, 40).map((c) => ({
    name: str(c.name, 40), platform: pick(c.platform, SOCIAL_PLATFORMS, 'twitch'), url: httpsOk(c.url, 'Creator ' + str(c.name, 40)), note: str(c.note, 100)
  })).filter((c) => c.name && c.url);
  const data = { intro: str(b.intro, 300), platforms, creators };
  await db.batch([
    db.prepare("INSERT INTO settings (key, value) VALUES ('socials', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").bind(JSON.stringify(data)),
    act(db, me, 'news', 'socials', null, `hat die Social-Media-Links aktualisiert (${SOCIAL_PLATFORMS.filter((k) => platforms[k].show && platforms[k].url).length} Kanäle, ${creators.length} Creator)`)
  ]);
  return json({ ok: true });
}

// ---------------------------------------------------------------- FiveM-Server ⇄ Panel
// Der Ingame-Admin-Menü-Resource (rls_admin) spricht mit diesen Endpunkten. Schutz: Server-Schlüssel
// im Header „X-RLS-Key“. Der Schlüssel wird im Panel (Einstellungen) erzeugt, gespeichert wird nur sein Hash.
PANEL_SCHEMA.push(
  `CREATE TABLE IF NOT EXISTS server_commands (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, payload TEXT, created_by INTEGER, created_at TEXT NOT NULL, delivered_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS dev_coords (id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT NOT NULL, category TEXT, x REAL NOT NULL, y REAL NOT NULL, z REAL NOT NULL, h REAL, admin_id INTEGER, admin_name TEXT, created_at TEXT NOT NULL)`
);
PANEL_SCHEMA.push(
  `CREATE TABLE IF NOT EXISTS server_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, text TEXT NOT NULL, player TEXT, admin TEXT, x REAL, y REAL, z REAL, created_at TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_server_logs_created ON server_logs (created_at)`,
  `CREATE TABLE IF NOT EXISTS server_reports (id INTEGER PRIMARY KEY AUTOINCREMENT, server_id INTEGER, name TEXT NOT NULL, license TEXT, text TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'offen', claimed_by TEXT, x REAL, y REAL, z REAL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`
);
COLUMN_MIGRATIONS.push(['sanctions', 'ingame_admin', 'TEXT']);
COLUMN_MIGRATIONS.push(['server_reports', 'clip_url', 'TEXT']);

const getSetting = async (db, key) => (await db.prepare('SELECT value FROM settings WHERE key = ?').bind(key).first())?.value ?? null;
const putSetting = (db, key, value) => db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').bind(key, value);
const parseJson = (s, d) => { try { return s ? JSON.parse(s) : d; } catch { return d; } };
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0; };
const cleanLicense = (v) => str(v, 80).replace(/^license:/, '');

async function requireServer(request, env) {
  await ensureSchema(env.DB);
  const key = request.headers.get('X-RLS-Key') || '';
  const hash = await getSetting(env.DB, 'server_key_hash');
  if (!hash || !key || !safeEqual(await sha256(key), hash)) throw new HttpError('Server-Schlüssel fehlt oder ist falsch.', 401);
}
async function findOrCreatePlayer(db, t) {
  const lic = cleanLicense(t.license), dc = str(t.discord, 40).replace(/^discord:/, ''), name = str(t.name, 60) || 'Unbekannt';
  let p = null;
  if (lic) p = await db.prepare("SELECT * FROM players WHERE license = ? OR license = 'license:' || ? LIMIT 1").bind(lic, lic).first();
  if (!p && dc) p = await db.prepare('SELECT * FROM players WHERE discord = ? LIMIT 1').bind(dc).first();
  if (p) {
    // Discord-ID nachtragen, damit der Launcher Bans erkennt
    if (dc && /^\d{15,22}$/.test(dc) && !/^\d{15,22}$/.test(String(p.discord || ''))) await db.prepare('UPDATE players SET discord = ? WHERE id = ?').bind(dc, p.id).run();
    return p;
  }
  const r = await db.prepare('INSERT INTO players (name, discord, license, notes, watch, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, 0, NULL, ?, ?)')
    .bind(name, dc, lic ? 'license:' + lic : '', 'Automatisch angelegt durch das Ingame-Admin-Menü.', now(), now()).run();
  return { id: r.meta.last_row_id, name };
}
async function queueKickForLicense(db, license, reason, by) {
  const lic = cleanLicense(license); if (!lic) return;
  const live = parseJson(await getSetting(db, 'server_live'), null);
  const hit = live && (live.players || []).find((p) => cleanLicense(p.license) === lic);
  if (hit) await db.prepare("INSERT INTO server_commands (type, payload, created_by, created_at) VALUES ('kick', ?, ?, ?)").bind(JSON.stringify({ target: hit.id, reason }), by || null, now()).run();
}

// ---------- vom FiveM-Server aufgerufen
async function serverSync({ request, env }) {
  await requireServer(request, env);
  const b = await readBody(request);
  const resources = (Array.isArray(b.resources) ? b.resources : []).slice(0, 600).map((r) => ({ name: str(r.name, 80), state: str(r.state, 20), version: str(r.version, 30), author: str(r.author, 60), description: str(r.description, 140) })).filter((r) => r.name);
  const items = (Array.isArray(b.items) ? b.items : []).slice(0, 3000).map((i) => ({ name: str(i.name, 60), label: str(i.label, 80), weight: num(i.weight) })).filter((i) => i.name);
  const info = { name: str(b.info?.name, 120), maxPlayers: parseInt(b.info?.maxPlayers, 10) || 0, framework: str(b.info?.framework, 40), inventory: str(b.info?.inventory, 40) };
  await putSetting(env.DB, 'server_state', JSON.stringify({ resources, items, info, synced_at: now() })).run();
  return json({ ok: true, resources: resources.length, items: items.length });
}
async function takeCommands(db) {
  const cmds = await all(db.prepare('SELECT id, type, payload FROM server_commands WHERE delivered_at IS NULL AND created_at > ? ORDER BY id LIMIT 20').bind(isoAgo(10 * 60e3)));
  if (cmds.length) await db.prepare(`UPDATE server_commands SET delivered_at = ? WHERE id IN (${cmds.map(() => '?').join(',')})`).bind(now(), ...cmds.map((c) => c.id)).run();
  return cmds.map((c) => ({ id: c.id, type: c.type, ...parseJson(c.payload, {}) }));
}
async function serverHeartbeat({ request, env }) {
  await requireServer(request, env);
  const db = env.DB, b = await readBody(request);
  const players = (Array.isArray(b.players) ? b.players : []).slice(0, 2048).map((p) => ({ id: parseInt(p.id, 10) || 0, name: str(p.name, 60), ping: parseInt(p.ping, 10) || 0, job: str(p.job, 60), group: str(p.group, 30), license: cleanLicense(p.license), discord: str(p.discord, 40).replace(/^discord:/, ''), x: num(p.x), y: num(p.y), z: num(p.z), staff: !!p.staff, dead: !!p.dead, veh: str(p.veh, 30) }));
  const restartIn = b.restartIn === undefined || b.restartIn === null ? null : Math.max(0, parseInt(b.restartIn, 10) || 0);
  await putSetting(db, 'server_live', JSON.stringify({ players, maxPlayers: parseInt(b.maxPlayers, 10) || 0, uptime: parseInt(b.uptime, 10) || 0, at: now(), restartAt: restartIn === null ? null : new Date(Date.now() + restartIn * 1000).toISOString(), restartReason: str(b.restartReason, 120), maintenance: !!b.maintenance })).run();
  return json({ ok: true, commands: await takeCommands(db), maintenance: parseJson(await getSetting(db, 'server_maintenance'), { on: false }) });
}
// schneller Abruf (alle paar Sekunden), damit Befehle aus dem Panel sofort ingame ankommen
async function serverCommands({ request, env }) {
  await requireServer(request, env);
  return json({ ok: true, commands: await takeCommands(env.DB), maintenance: parseJson(await getSetting(env.DB, 'server_maintenance'), { on: false }) });
}
// Wartungsmodus wurde ingame umgeschaltet → im Panel merken, damit er nach einem Neustart erhalten bleibt
async function serverMaintenance({ request, env }) {
  await requireServer(request, env);
  const b = await readBody(request);
  await env.DB.batch([
    putSetting(env.DB, 'server_maintenance', JSON.stringify({ on: !!b.on, reason: str(b.reason, 160), by: str(b.by, 60) })),
    act(env.DB, null, 'server', 'server', null, `🎮 ${str(b.by, 60) || 'Admin'} (ingame) hat den Wartungsmodus ${b.on ? 'eingeschaltet' : 'ausgeschaltet'}`)
  ]);
  return json({ ok: true });
}
async function serverBanCheck({ request, env, url }) {
  await requireServer(request, env);
  const db = env.DB, lic = cleanLicense(url.searchParams.get('license')), dc = str(url.searchParams.get('discord'), 40).replace(/^discord:/, '');
  if (!lic && !dc) return json({ banned: false });
  const p = await db.prepare("SELECT id, name FROM players WHERE (? <> '' AND (license = ? OR license = 'license:' || ?)) OR (? <> '' AND discord = ?) LIMIT 1").bind(lic, lic, lic, dc, dc).first();
  if (!p) return json({ banned: false });
  const s = await db.prepare("SELECT type, reason, expires_at FROM sanctions WHERE player_id = ? AND type IN ('ban','permaban') AND active = 1 AND (expires_at IS NULL OR expires_at > ?) ORDER BY expires_at IS NULL DESC, expires_at DESC LIMIT 1").bind(p.id, now()).first();
  return json(s ? { banned: true, permanent: s.type === 'permaban' || !s.expires_at, reason: s.reason, until: s.expires_at } : { banned: false });
}
async function serverSanction({ request, env, ctx }) {
  await requireServer(request, env);
  const db = env.DB, b = await readBody(request);
  const type = pick(b.type, ['hinweis', 'verwarnung', 'kick', 'ban', 'permaban'], '');
  const reason = str(b.reason, 1000) || 'Kein Grund angegeben', admin = str(b.admin, 60) || 'Admin';
  if (!type) throw new HttpError('Unbekannte Sanktion.');
  const p = await findOrCreatePlayer(db, b.target || {});
  let expires = null, duration = null;
  if (type === 'ban') { const h = Math.min(Math.max(Number(b.hours) || 24, 1), 24 * 365); expires = new Date(Date.now() + h * 3600e3).toISOString(); duration = h < 24 ? `${h} Std.` : `${Math.round(h / 24)} Tag${h === 24 ? '' : 'e'}`; }
  if (type === 'permaban') duration = 'permanent';
  await db.batch([
    db.prepare('INSERT INTO sanctions (player_id, type, reason, duration, expires_at, active, admin_id, created_at, ingame_admin) VALUES (?, ?, ?, ?, ?, 1, NULL, ?, ?)').bind(p.id, type, reason, duration, expires, now(), admin),
    db.prepare('UPDATE players SET updated_at = ? WHERE id = ?').bind(now(), p.id),
    act(db, null, 'spieler', 'player', p.id, `🎮 ${admin} (ingame) hat ${q(p.name)} sanktioniert: ${SANCTION_LABEL[type]}${type === 'ban' ? ' (' + duration + ')' : ''}`)
  ]);
  if (type === 'ban' || type === 'permaban') await discordNotify(env, ctx, { title: `🔨 ${SANCTION_LABEL[type]}: ${p.name}`, color: 0xff5a6e, description: `**Grund:** ${reason}\n**Dauer:** ${duration}\n**Von:** ${admin} (ingame)` });
  return json({ ok: true, player_id: p.id, until: expires });
}
async function serverCoords({ request, env }) {
  await requireServer(request, env);
  const db = env.DB, b = await readBody(request);
  const label = str(b.label, 80) || 'Ohne Namen';
  await db.batch([
    db.prepare('INSERT INTO dev_coords (label, category, x, y, z, h, admin_id, admin_name, created_at) VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)').bind(label, str(b.category, 40) || 'Allgemein', num(b.x), num(b.y), num(b.z), b.h === undefined || b.h === null ? null : num(b.h), str(b.admin, 60), now()),
    act(db, null, 'dev', 'coords', null, `🎮 ${str(b.admin, 60) || 'Admin'} (ingame) hat die Koordinate ${q(label)} gespeichert`)
  ]);
  return json({ ok: true });
}
async function serverLog({ request, env }) {
  await requireServer(request, env);
  const b = await readBody(request);
  const admin = str(b.admin, 60) || 'Admin', text = str(b.text, 240);
  await env.DB.batch([
    act(env.DB, null, 'server', 'server', null, `🎮 ${admin} (ingame) ${text}`),
    env.DB.prepare('INSERT INTO server_logs (kind, text, player, admin, created_at) VALUES (?, ?, ?, ?, ?)').bind('admin', `${admin} ${text}`, str(b.player, 60), admin, now())
  ]);
  return json({ ok: true });
}

// ---------- im Panel
async function getServerAdmin({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB;
  const [state, live, keySet, coords, list, cmds] = await Promise.all([
    getSetting(db, 'server_state'), getSetting(db, 'server_live'), getSetting(db, 'server_key_hash'),
    all(db.prepare('SELECT c.*, COALESCE(a.name, c.admin_name) AS by_name FROM dev_coords c LEFT JOIN admins a ON a.id = c.admin_id ORDER BY c.id DESC LIMIT 500')),
    all(db.prepare('SELECT LOWER(name) AS n FROM dev_resources')),
    all(db.prepare('SELECT c.id, c.type, c.payload, c.created_at, c.delivered_at, a.name AS by_name FROM server_commands c LEFT JOIN admins a ON a.id = c.created_by ORDER BY c.id DESC LIMIT 10'))
  ]);
  const [logs, reports] = await Promise.all([
    all(db.prepare('SELECT id, kind, text, player, admin, x, y, z, created_at FROM server_logs ORDER BY id DESC LIMIT 300')),
    all(db.prepare("SELECT * FROM server_reports WHERE status <> 'erledigt' OR updated_at > ? ORDER BY CASE status WHEN 'offen' THEN 0 WHEN 'angenommen' THEN 1 ELSE 2 END, id DESC LIMIT 60").bind(isoAgo(864e5)))
  ]);
  const st = parseJson(state, null), lv = parseJson(live, null), inList = new Set(list.map((r) => r.n));
  const online = !!(lv && lv.at && lv.at > isoAgo(150e3));
  return json({
    keySet: !!keySet, owner: me.role === 'owner', online, maintenance: parseJson(await getSetting(db, 'server_maintenance'), { on: false }), live: lv, info: st?.info || null, synced_at: st?.synced_at || null,
    resources: (st?.resources || []).map((r) => ({ ...r, inList: inList.has(r.name.toLowerCase()) })), items: st?.items || [], coords,
    commands: cmds.map((c) => ({ ...c, payload: parseJson(c.payload, {}) })), logs, reports
  });
}
async function createServerKey({ request, env }) {
  const me = await requireAdmin(request, env, true);
  const key = 'rls_' + randomString(40, 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789');
  await env.DB.batch([putSetting(env.DB, 'server_key_hash', await sha256(key)), act(env.DB, me, 'team', 'settings', null, 'hat einen neuen Server-Schlüssel für das Ingame-Menü erzeugt')]);
  return json({ ok: true, key });
}
async function sendServerCommand({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, b = await readBody(request);
  let payload, text;
  if (b.type === 'announce') { const msg = str(b.text, 240); if (len(msg) < 2) throw new HttpError('Was soll angekündigt werden?'); payload = { text: msg, by: me.name }; text = `hat ingame angekündigt: ${q(msg)}`; }
  else if (b.type === 'kick') { const t = parseInt(b.target, 10); if (!t) throw new HttpError('Welcher Spieler?'); payload = { target: t, reason: str(b.reason, 200) || 'Vom Team gekickt', by: me.name }; text = `hat Spieler-ID ${t} vom Server gekickt (${payload.reason})`; }
  else if (['heal', 'revive', 'freeze', 'unfreeze', 'message'].includes(b.type)) {
    const t = parseInt(b.target, 10); if (!t) throw new HttpError('Welcher Spieler?');
    payload = { target: t, by: me.name };
    if (b.type === 'message') { payload.text = str(b.text, 240); if (len(payload.text) < 2) throw new HttpError('Was willst du schreiben?'); }
    text = { heal: `hat Spieler-ID ${t} aus dem Panel geheilt`, revive: `hat Spieler-ID ${t} aus dem Panel wiederbelebt`, freeze: `hat Spieler-ID ${t} aus dem Panel eingefroren`, unfreeze: `hat Spieler-ID ${t} aus dem Panel aufgetaut`, message: `hat Spieler-ID ${t} eine Nachricht geschickt: ${q(payload.text || '')}` }[b.type];
  } else if (b.type === 'resource') {
    if (me.role !== 'owner') throw new HttpError('Ressourcen starten und stoppen darf nur der Owner.', 403);
    const what = pick(b.what, ['start', 'stop', 'restart'], ''), name = str(b.name, 80);
    if (!what || !/^[\w.-]+$/.test(name)) throw new HttpError('Unbekannte Ressource.');
    payload = { what, name, by: me.name }; text = `hat die Ressource ${q(name)} ${({ start: 'gestartet', stop: 'gestoppt', restart: 'neu gestartet' })[what]}`;
  } else if (b.type === 'sync') { payload = { by: me.name }; text = 'hat die Server-Daten neu angefordert'; }
  else if (['restart', 'cancelRestart', 'kickall', 'maintenance'].includes(b.type)) {
    if (me.role !== 'owner') throw new HttpError('Server-Steuerung darf nur der Owner.', 403);
    if (b.type === 'restart') { const m = Math.max(0, Math.min(60, parseInt(b.minutes, 10) || 0)); payload = { minutes: m, reason: str(b.reason, 120), by: me.name }; text = `hat einen Server-Neustart ${m ? 'in ' + m + ' Min.' : 'sofort'} ausgelöst${payload.reason ? ' (' + payload.reason + ')' : ''}`; }
    else if (b.type === 'cancelRestart') { payload = { by: me.name }; text = 'hat den Server-Neustart abgebrochen'; }
    else if (b.type === 'kickall') { payload = { reason: str(b.reason, 200), by: me.name }; text = 'hat alle Spieler vom Server gekickt'; }
    else {
      const on = !!b.on, reason = str(b.reason, 160);
      await putSetting(db, 'server_maintenance', JSON.stringify({ on, reason, by: me.name })).run();
      await act(db, me, 'server', 'server', null, `hat den Wartungsmodus ${on ? 'eingeschaltet' : 'ausgeschaltet'}`).run();
      return json({ ok: true });
    }
  }
  else throw new HttpError('Unbekannter Befehl.');
  await db.batch([
    db.prepare('INSERT INTO server_commands (type, payload, created_by, created_at) VALUES (?, ?, ?, ?)').bind(b.type, JSON.stringify(payload), me.id, now()),
    act(db, me, 'server', 'server', null, text)
  ]);
  return json({ ok: true });
}
async function addCoordPanel({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, b = await readBody(request);
  const label = str(b.label, 80); if (len(label) < 2) throw new HttpError('Gib der Koordinate einen Namen.');
  const m = String(b.vector || '').match(/-?\d+(?:\.\d+)?/g);
  if (!m || m.length < 3) throw new HttpError('Füge die Koordinate ein, z. B. vector3(215.76, -810.12, 30.73).');
  await db.batch([
    db.prepare('INSERT INTO dev_coords (label, category, x, y, z, h, admin_id, admin_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)').bind(label, str(b.category, 40) || 'Allgemein', num(m[0]), num(m[1]), num(m[2]), m[3] !== undefined ? num(m[3]) : null, me.id, me.name, now()),
    act(db, me, 'dev', 'coords', null, `hat die Koordinate ${q(label)} gespeichert`)
  ]);
  return json({ ok: true }, 201);
}
async function deleteCoord({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const c = await db.prepare('SELECT label FROM dev_coords WHERE id = ?').bind(id).first();
  if (!c) return json({ ok: true });
  await db.batch([db.prepare('DELETE FROM dev_coords WHERE id = ?').bind(id), act(db, me, 'dev', 'coords', null, `hat die Koordinate ${q(c.label)} gelöscht`)]);
  return json({ ok: true });
}
async function importResources({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, b = await readBody(request);
  const st = parseJson(await getSetting(db, 'server_state'), null);
  const want = new Set((Array.isArray(b.names) ? b.names : []).map((n) => String(n).toLowerCase()));
  const have = new Set((await all(db.prepare('SELECT LOWER(name) AS n FROM dev_resources'))).map((r) => r.n));
  const add = (st?.resources || []).filter((r) => want.has(r.name.toLowerCase()) && !have.has(r.name.toLowerCase())).slice(0, 300);
  if (!add.length) return json({ ok: true, added: 0 });
  await db.batch([
    ...add.map((r) => db.prepare('INSERT INTO dev_resources (name, version, kind, status, source, notes, admin_id, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').bind(r.name, r.version, /^esx_|^es_extended/.test(r.name) ? 'ESX' : 'Sonstiges', r.state === 'started' ? 'aktiv' : 'aus', '', [r.author && 'Autor: ' + r.author, r.description].filter(Boolean).join(' · '), me.id, now())),
    act(db, me, 'dev', 'resource', null, `hat ${add.length} Ressource${add.length === 1 ? '' : 'n'} vom Server in die Scripts-Liste übernommen`)
  ]);
  return json({ ok: true, added: add.length });
}

// ---------- Logs, Reports, Akte, Bans (vom FiveM-Server)
const LOG_KINDS = ['join', 'leave', 'death', 'admin', 'report', 'chat', 'resource'];
async function serverLogs({ request, env }) {
  await requireServer(request, env);
  const db = env.DB, b = await readBody(request);
  const logs = (Array.isArray(b.logs) ? b.logs : []).slice(0, 100).map((l) => ({ kind: pick(l.kind, LOG_KINDS, 'admin'), text: str(l.text, 300), player: str(l.player, 60), admin: str(l.admin, 60), x: l.x == null ? null : num(l.x), y: l.y == null ? null : num(l.y), z: l.z == null ? null : num(l.z) })).filter((l) => l.text);
  if (!logs.length) return json({ ok: true, saved: 0 });
  await db.batch([
    ...logs.map((l) => db.prepare('INSERT INTO server_logs (kind, text, player, admin, x, y, z, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').bind(l.kind, l.text, l.player, l.admin, l.x, l.y, l.z, now())),
    db.prepare('DELETE FROM server_logs WHERE created_at < ?').bind(isoAgo(14 * 864e5))
  ]);
  return json({ ok: true, saved: logs.length });
}
async function serverReport({ request, env, ctx }) {
  await requireServer(request, env);
  const db = env.DB, b = await readBody(request);
  const text = str(b.text, 500), name = str(b.name, 60) || 'Unbekannt';
  if (len(text) < 3) throw new HttpError('Report ist leer.');
  const r = await db.prepare('INSERT INTO server_reports (server_id, name, license, text, status, x, y, z, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(parseInt(b.id, 10) || null, name, cleanLicense(b.license), text, 'offen', b.x == null ? null : num(b.x), b.y == null ? null : num(b.y), b.z == null ? null : num(b.z), now(), now()).run();
  await act(db, null, 'server', 'server', null, `🆘 Neuer Report von ${q(name)}: ${q(text.slice(0, 120))}`).run();
  return json({ ok: true, id: r.meta.last_row_id });
}
async function serverReportUpdate({ request, env, params }) {
  await requireServer(request, env);
  const db = env.DB, b = await readBody(request), id = Number(params.id);
  const status = pick(b.status, ['offen', 'angenommen', 'erledigt'], '');
  if (!status) throw new HttpError('Unbekannter Status.');
  const clip = /^https?:\/\/[^\s"'<>]{4,250}$/.test(String(b.clip || '')) ? String(b.clip) : null;
  await db.prepare('UPDATE server_reports SET status = ?, claimed_by = COALESCE(?, claimed_by), clip_url = COALESCE(?, clip_url), updated_at = ? WHERE id = ?').bind(status, str(b.admin, 60) || null, clip, now(), id).run();
  return json({ ok: true });
}
async function serverReports({ request, env }) {
  await requireServer(request, env);
  return json({ rows: await all(env.DB.prepare("SELECT * FROM server_reports WHERE status <> 'erledigt' AND created_at > ? ORDER BY id DESC LIMIT 50").bind(isoAgo(864e5))) });
}
async function serverPlayerFile({ request, env, url }) {
  await requireServer(request, env);
  const db = env.DB, lic = cleanLicense(url.searchParams.get('license'));
  if (!lic) return json({ found: false });
  const p = await db.prepare("SELECT id, name, notes, watch, created_at FROM players WHERE license = ? OR license = 'license:' || ? LIMIT 1").bind(lic, lic).first();
  if (!p) return json({ found: false });
  const sanctions = await all(db.prepare('SELECT s.id, s.type, s.reason, s.duration, s.expires_at, s.active, s.created_at, COALESCE(a.name, s.ingame_admin) AS by_name FROM sanctions s LEFT JOIN admins a ON a.id = s.admin_id WHERE s.player_id = ? ORDER BY s.id DESC LIMIT 15').bind(p.id));
  return json({ found: true, player: p, sanctions });
}
async function serverBans({ request, env }) {
  await requireServer(request, env);
  const rows = await all(env.DB.prepare("SELECT s.id, s.type, s.reason, s.duration, s.expires_at, s.created_at, p.name, COALESCE(a.name, s.ingame_admin) AS by_name FROM sanctions s JOIN players p ON p.id = s.player_id LEFT JOIN admins a ON a.id = s.admin_id WHERE s.type IN ('ban','permaban') AND s.active = 1 AND (s.expires_at IS NULL OR s.expires_at > ?) ORDER BY s.id DESC LIMIT 100").bind(now()));
  return json({ rows });
}
async function serverUnban({ request, env }) {
  await requireServer(request, env);
  const db = env.DB, b = await readBody(request), id = parseInt(b.id, 10), admin = str(b.admin, 60) || 'Admin';
  const s = await db.prepare("SELECT s.id, p.id AS pid, p.name FROM sanctions s JOIN players p ON p.id = s.player_id WHERE s.id = ? AND s.type IN ('ban','permaban')").bind(id).first();
  if (!s) throw new HttpError('Ban nicht gefunden.', 404);
  await db.batch([
    db.prepare('UPDATE sanctions SET active = 0, lifted_by = NULL, lifted_at = ? WHERE id = ?').bind(now(), id),
    act(db, null, 'spieler', 'player', s.pid, `🎮 ${admin} (ingame) hat den Ban von ${q(s.name)} aufgehoben`)
  ]);
  return json({ ok: true });
}

// ---------- im Panel: Logs & Reports
async function setReportPanel({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, b = await readBody(request), id = Number(params.id);
  const status = pick(b.status, ['offen', 'angenommen', 'erledigt'], '');
  if (!status) throw new HttpError('Unbekannter Status.');
  const r = await db.prepare('SELECT name FROM server_reports WHERE id = ?').bind(id).first();
  if (!r) throw new HttpError('Report nicht gefunden.', 404);
  await db.batch([
    db.prepare('UPDATE server_reports SET status = ?, claimed_by = ?, updated_at = ? WHERE id = ?').bind(status, status === 'offen' ? null : me.name + ' (Web)', now(), id),
    db.prepare('INSERT INTO server_commands (type, payload, created_by, created_at) VALUES (?, ?, ?, ?)').bind('report', JSON.stringify({ report: id, status, by: me.name }), me.id, now()),
    act(db, me, 'server', 'server', null, `hat den Report von ${q(r.name)} auf „${status}“ gesetzt`)
  ]);
  return json({ ok: true });
}

// ---------------------------------------------------------------- Router

// ---------------------------------------------------------------- Planung: Social Media, Events, Fraktionen, Teamdokumente, Projekt
// Ein gemeinsamer Speicher für alle Planungs-Reiter. Feste Felder (Titel, Status, Datum, Zuständig) als Spalten,
// alles andere als JSON in "data". Welche Bereiche und Reiter es gibt, steht hier – das Panel kennt die Felder.
PANEL_SCHEMA.push(
  `CREATE TABLE IF NOT EXISTS plan_items (id INTEGER PRIMARY KEY AUTOINCREMENT, area TEXT NOT NULL, tab TEXT NOT NULL, title TEXT NOT NULL, status TEXT, date TEXT, owner_id INTEGER, data TEXT, sort INTEGER NOT NULL DEFAULT 0, created_by INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_plan_area ON plan_items(area, tab)`
);
const PLAN = {
  social: { name: 'Social Media', tabs: { posts: 'Beitrag', ideen: 'Idee', kampagnen: 'Kampagne', stats: 'Kennzahl', vorlagen: 'Vorlage' } },
  events: { name: 'Events', tabs: { events: 'Event', ideen: 'Event-Idee', preise: 'Preis/Sponsor' } },
  frak: { name: 'Fraktionen', tabs: { fraktionen: 'Fraktion', bewerbungen: 'Fraktionsbewerbung', strikes: 'Verwarnung', aktivitaet: 'Aktivitätsprüfung', gebiete: 'Gebiet' } },
  docs: { name: 'Teamdokumente', tabs: { dokumente: 'Dokument', protokolle: 'Protokoll', onboarding: 'Einarbeitung', links: 'Link' } },
  projekt: { name: 'Projektplanung', tabs: { ziele: 'Ziel', finanzen: 'Buchung', partner: 'Partner', feedback: 'Feedback' } }
};
const planRow = (r) => ({ ...r, data: parseJson(r.data, {}) });
function planInput(b, area) {
  const tab = str(b.tab, 30);
  if (!PLAN[area] || !PLAN[area].tabs[tab]) throw new HttpError('Unbekannter Bereich.');
  const title = str(b.title, 160);
  if (!title) throw new HttpError('Bitte gib einen Titel ein.');
  const date = /^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2})?$/.test(String(b.date || '')) ? String(b.date) : null;
  const data = JSON.stringify(b.data && typeof b.data === 'object' && !Array.isArray(b.data) ? b.data : {});
  if (data.length > 150000) throw new HttpError('Der Eintrag ist zu groß (max. ca. 150.000 Zeichen).');
  return { tab, title, status: str(b.status, 30) || null, date, owner_id: idOrNull(b.owner_id), data, sort: Number.isFinite(+b.sort) ? Math.round(+b.sort) : 0 };
}
async function listPlan({ request, env, url }) {
  await requireAdmin(request, env);
  const area = str(url.searchParams.get('area'), 20);
  if (!PLAN[area]) throw new HttpError('Unbekannter Bereich.');
  const [items, team] = await Promise.all([
    all(env.DB.prepare('SELECT p.*, a.name AS owner_name, c.name AS creator_name FROM plan_items p LEFT JOIN admins a ON a.id = p.owner_id LEFT JOIN admins c ON c.id = p.created_by WHERE p.area = ? ORDER BY p.sort, p.id DESC').bind(area)),
    all(env.DB.prepare('SELECT id, name FROM admins WHERE active = 1 ORDER BY name'))
  ]);
  return json({ items: items.map(planRow), team });
}
async function getPlanItem({ request, env, params }) {
  await requireAdmin(request, env);
  const r = await env.DB.prepare('SELECT id, area, tab, title FROM plan_items WHERE id = ?').bind(Number(params.id)).first();
  if (!r) throw new HttpError('Diesen Eintrag gibt es nicht mehr.', 404);
  return json({ item: r });
}
async function createPlan({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, b = await readBody(request), area = str(b.area, 20), x = planInput(b, area), n = now();
  const r = await db.prepare('INSERT INTO plan_items (area, tab, title, status, date, owner_id, data, sort, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(area, x.tab, x.title, x.status, x.date, x.owner_id, x.data, x.sort, me.id, n, n).run();
  const id = r.meta.last_row_id;
  await act(db, me, 'plan', 'plan', id, `hat ${PLAN[area].tabs[x.tab]} ${q(x.title)} angelegt (${PLAN[area].name})`).run();
  return json({ ok: true, id }, 201);
}
async function updatePlan({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id), b = await readBody(request);
  const old = await db.prepare('SELECT * FROM plan_items WHERE id = ?').bind(id).first();
  if (!old) throw new HttpError('Diesen Eintrag gibt es nicht mehr.', 404);
  const x = planInput({ tab: old.tab, title: old.title, status: old.status, date: old.date, owner_id: old.owner_id, sort: old.sort, data: parseJson(old.data, {}), ...b }, old.area);
  await db.prepare('UPDATE plan_items SET tab = ?, title = ?, status = ?, date = ?, owner_id = ?, data = ?, sort = ?, updated_at = ? WHERE id = ?')
    .bind(x.tab, x.title, x.status, x.date, x.owner_id, x.data, x.sort, now(), id).run();
  const what = b.status !== undefined && b.status !== old.status && Object.keys(b).length <= 2 ? `hat ${q(x.title)} auf „${x.status}“ gesetzt` : `hat ${q(x.title)} bearbeitet`;
  if (!b.quiet) await act(db, me, 'plan', 'plan', id, `${what} (${PLAN[old.area].name})`).run();
  return json({ ok: true });
}
async function deletePlan({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id);
  const old = await db.prepare('SELECT * FROM plan_items WHERE id = ?').bind(id).first();
  if (!old) return json({ ok: true });
  if (old.created_by !== me.id && me.role !== 'owner') throw new HttpError('Löschen darf nur, wer es angelegt hat, oder der Owner.', 403);
  await db.batch([db.prepare('DELETE FROM plan_items WHERE id = ?').bind(id), act(db, me, 'plan', 'plan', null, `hat ${q(old.title)} gelöscht (${PLAN[old.area].name})`)]);
  return json({ ok: true });
}


// ---------------------------------------------------------------- Teamwarns: Verwarnungen fürs Team mit Stufen, Punkten und Ablauf
// Nutzt team_records (kind = 'verwarnung'), damit alte Einträge aus der Teamakte weiter zählen.
COLUMN_MIGRATIONS.push(
  ['team_records', 'level', 'TEXT'], ['team_records', 'points', 'INTEGER'], ['team_records', 'category', 'TEXT'],
  ['team_records', 'expires_at', 'TEXT'], ['team_records', 'lifted_by', 'INTEGER'], ['team_records', 'lifted_at', 'TEXT'],
  ['team_records', 'lift_reason', 'TEXT'], ['team_records', 'ack_at', 'TEXT'], ['team_records', 'statement', 'TEXT']
);
const TW_LEVELS = { hinweis: 0, verwarnung: 1, schwer: 2, letzte: 3 };
const TW_LABEL = { hinweis: 'Hinweis', verwarnung: 'Verwarnung', schwer: 'Schwere Verwarnung', letzte: 'Letzte Verwarnung' };
const TW_CATS = ['Verhalten im Support', 'Inaktivität', 'Rechte-Missbrauch', 'Umgangston', 'Regelverstoß ingame', 'Absprachen nicht eingehalten', 'Datenschutz', 'Sonstiges'];
const twStatus = (r, n) => (r.lifted_at ? 'aufgehoben' : r.expires_at && r.expires_at < n ? 'abgelaufen' : 'aktiv');
async function listTeamWarns({ request, env }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, owner = me.role === 'owner', n = now();
  const rows = await all(db.prepare(`SELECT r.*, a.name AS admin_name, b.name AS by_name, l.name AS lifted_name FROM team_records r
      JOIN admins a ON a.id = r.admin_id LEFT JOIN admins b ON b.id = r.by_id LEFT JOIN admins l ON l.id = r.lifted_by
      WHERE r.kind = 'verwarnung' ${owner ? '' : 'AND r.admin_id = ?'} ORDER BY r.id DESC`).bind(...(owner ? [] : [me.id])));
  const warns = rows.map((r) => {
    const level = TW_LEVELS[r.level] !== undefined ? r.level : 'verwarnung';
    return { id: r.id, admin_id: r.admin_id, admin_name: r.admin_name, by_name: r.by_name, level, label: TW_LABEL[level], points: r.points ?? TW_LEVELS[level], category: r.category || '', text: r.text,
      created_at: r.created_at, expires_at: r.expires_at, status: twStatus(r, n), lifted_name: r.lifted_name, lifted_at: r.lifted_at, lift_reason: r.lift_reason, ack_at: r.ack_at, statement: r.statement };
  });
  const team = owner ? await all(db.prepare('SELECT a.id, a.name, p.rank FROM admins a LEFT JOIN team_profiles p ON p.admin_id = a.id WHERE a.active = 1 ORDER BY a.name')) : [];
  return json({ owner, me: me.id, warns, team, levels: TW_LABEL, points: TW_LEVELS, categories: TW_CATS });
}
async function createTeamWarn({ request, env }) {
  const me = await requireAdmin(request, env, true);
  const db = env.DB, b = await readBody(request), id = idOrNull(b.admin_id);
  const t = id && await db.prepare('SELECT name FROM admins WHERE id = ?').bind(id).first();
  if (!t) throw new HttpError('Wen willst du verwarnen?');
  if (id === me.id) throw new HttpError('Dich selbst kannst du nicht verwarnen.');
  const level = pick(b.level, Object.keys(TW_LEVELS), ''), text = str(b.text, 2000), cat = pick(b.category, TW_CATS, 'Sonstiges');
  if (!level) throw new HttpError('Wähl die Stufe.');
  if (len(text) < 5) throw new HttpError('Schreib kurz, was passiert ist.');
  const days = Math.max(0, Math.min(365, parseInt(b.days, 10) || 0));
  const exp = days ? new Date(Date.now() + days * 864e5).toISOString() : null;
  const pts = Math.max(0, Math.min(10, Number.isFinite(+b.points) && b.points !== '' && b.points !== null ? Math.round(+b.points) : TW_LEVELS[level]));
  const r = await db.prepare('INSERT INTO team_records (admin_id, kind, text, by_id, created_at, level, points, category, expires_at) VALUES (?, \'verwarnung\', ?, ?, ?, ?, ?, ?, ?)')
    .bind(id, text, me.id, now(), level, pts, cat, exp).run();
  await act(db, me, 'team', 'teamwarn', r.meta.last_row_id, 'hat eine Teamwarn eingetragen').run();
  return json({ ok: true }, 201);
}
async function liftTeamWarn({ request, env, params }) {
  const me = await requireAdmin(request, env, true);
  const db = env.DB, id = Number(params.id), b = await readBody(request);
  const r = await db.prepare("SELECT r.*, a.name FROM team_records r JOIN admins a ON a.id = r.admin_id WHERE r.id = ? AND r.kind = 'verwarnung'").bind(id).first();
  if (!r) throw new HttpError('Diese Verwarnung gibt es nicht mehr.', 404);
  if (r.lifted_at) return json({ ok: true });
  await db.batch([db.prepare('UPDATE team_records SET lifted_by = ?, lifted_at = ?, lift_reason = ? WHERE id = ?').bind(me.id, now(), str(b.reason, 500), id),
    act(db, me, 'team', 'teamwarn', id, 'hat eine Teamwarn aufgehoben')]);
  return json({ ok: true });
}
async function ackTeamWarn({ request, env, params }) {
  const me = await requireAdmin(request, env);
  const db = env.DB, id = Number(params.id), b = await readBody(request);
  const r = await db.prepare("SELECT * FROM team_records WHERE id = ? AND kind = 'verwarnung'").bind(id).first();
  if (!r) throw new HttpError('Diese Verwarnung gibt es nicht mehr.', 404);
  if (r.admin_id !== me.id) throw new HttpError('Nur die verwarnte Person kann das bestätigen.', 403);
  const st = str(b.statement, 1500);
  // bewusst ohne Eintrag im Protokoll: Verwarnungen sollen nicht für das ganze Team sichtbar sein
  await db.prepare('UPDATE team_records SET ack_at = COALESCE(ack_at, ?), statement = ? WHERE id = ?').bind(now(), st || r.statement || null, id).run();
  return json({ ok: true });
}


// ---------------------------------------------------------------- Besucher- & Launcher-Statistik
// Jede Person zählt nur einmal: Die Website gibt jedem Browser eine zufällige Besucher-Nummer (localStorage),
// der Launcher jedem PC eine zufällige Installations-Nummer. Gespeichert wird davon nur ein Hash.
// Keine IP-Adressen, keine Namen, keine Cookies.
PANEL_SCHEMA.push(
  `CREATE TABLE IF NOT EXISTS stats_visitors (id TEXT PRIMARY KEY, first_seen TEXT NOT NULL, last_seen TEXT NOT NULL, visits INTEGER NOT NULL DEFAULT 0, pages INTEGER NOT NULL DEFAULT 0, ref TEXT, country TEXT, device TEXT, first_page TEXT, downloaded TEXT)`,
  `CREATE TABLE IF NOT EXISTS stats_seen (day TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL, PRIMARY KEY (day, kind, id))`,
  `CREATE TABLE IF NOT EXISTS stats_pages (day TEXT NOT NULL, path TEXT NOT NULL, views INTEGER NOT NULL DEFAULT 0, people INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (day, path))`,
  `CREATE TABLE IF NOT EXISTS launcher_installs (id TEXT PRIMARY KEY, first_seen TEXT NOT NULL, last_seen TEXT NOT NULL, version TEXT, opens INTEGER NOT NULL DEFAULT 0, plays INTEGER NOT NULL DEFAULT 0, last_play TEXT)`
);
const BOT_RE = /bot|crawl|spider|slurp|preview|facebookexternalhit|discordbot|headless|curl|wget|python|scrapy|monitor|lighthouse/i;
const trackOk = () => new Response(null, { status: 204, headers: { 'Access-Control-Allow-Origin': '*' } });
async function idHash(env, raw) { return (await sha256('rls-stats|' + (env.SETUP_KEY || '') + '|' + raw)).slice(0, 32); }

async function postTrack({ request, env, url }) {
  const ua = request.headers.get('User-Agent') || '';
  if (BOT_RE.test(ua)) return trackOk();
  const b = await readBody(request).catch(() => ({}));
  const raw = String(b.v || '');
  if (!/^[a-f0-9]{24,40}$/.test(raw)) return trackOk();
  const db = env.DB; await ensureSchema(db);
  const id = await idHash(env, raw), n = now(), day = n.slice(0, 10);
  const one = (sql, ...a) => db.prepare(sql).bind(...a);
  if (b.t === 'dl') {
    await db.batch([one('UPDATE stats_visitors SET downloaded = COALESCE(downloaded, ?), last_seen = ? WHERE id = ?', n, n, id), one('INSERT OR IGNORE INTO stats_seen (day, kind, id) VALUES (?, ?, ?)', day, 'dl', id)]);
    return trackOk();
  }
  if (b.t !== 'pv') return trackOk();
  let path = String(b.p || '/').split('?')[0].split('#')[0].slice(0, 60);
  if (path === '/' || path === '') path = '/index.html';
  if (!/\.html$/.test(path)) path = path.replace(/\/$/, '') + '.html';
  if (!/^\/[a-z0-9\-_.\/]*$/i.test(path) || /^\/admin/.test(path)) return trackOk();
  let ref = '';
  try { const r = new URL(String(b.r || '')); if (r.host !== url.host) ref = r.host.replace(/^www\./, '').slice(0, 60); } catch {}
  const w = +b.w || 0, device = w && w < 768 ? 'Handy' : w && w < 1100 ? 'Tablet' : 'PC';
  const country = String((request.cf && request.cf.country) || request.headers.get('CF-IPCountry') || '').slice(0, 2).toUpperCase();
  // Neue Person? Neuer Tag für diese Person? Neue Seite für diese Person an diesem Tag?
  const [ins, dayNew, pageNew] = await db.batch([
    one('INSERT OR IGNORE INTO stats_visitors (id, first_seen, last_seen, visits, pages, ref, country, device, first_page) VALUES (?, ?, ?, 0, 0, ?, ?, ?, ?)', id, n, n, ref || null, country || null, device, path),
    one('INSERT OR IGNORE INTO stats_seen (day, kind, id) VALUES (?, ?, ?)', day, 'v', id),
    one('INSERT OR IGNORE INTO stats_seen (day, kind, id) VALUES (?, ?, ?)', day, 'p:' + path, id)
  ]);
  const ch = (r) => (r && (r.meta ? r.meta.changes : r.changes)) || 0;
  await db.batch([
    one('UPDATE stats_visitors SET last_seen = ?, pages = pages + 1, visits = visits + ? WHERE id = ?', n, ch(dayNew) ? 1 : 0, id),
    one('INSERT INTO stats_pages (day, path, views, people) VALUES (?, ?, 1, ?) ON CONFLICT(day, path) DO UPDATE SET views = views + 1, people = people + excluded.people', day, path, ch(pageNew) ? 1 : 0)
  ]);
  void ins;
  if (Math.random() < 0.02) await db.prepare("DELETE FROM stats_seen WHERE day < ? AND kind LIKE 'p:%'").bind(isoAgo(3 * 864e5).slice(0, 10)).run();
  return trackOk();
}

async function postTrackLauncher({ request, env }) {
  const b = await readBody(request).catch(() => ({}));
  const raw = String(b.id || '');
  if (!/^[a-f0-9]{32}$/.test(raw)) return trackOk();
  const db = env.DB; await ensureSchema(db);
  const id = await idHash(env, 'launcher|' + raw), n = now(), day = n.slice(0, 10), v = str(b.version, 20) || null, play = b.e === 'play';
  await db.batch([
    db.prepare('INSERT INTO launcher_installs (id, first_seen, last_seen, version, opens, plays, last_play) VALUES (?, ?, ?, ?, 0, 0, NULL) ON CONFLICT(id) DO UPDATE SET last_seen = excluded.last_seen, version = COALESCE(excluded.version, version)').bind(id, n, n, v),
    db.prepare(play ? 'UPDATE launcher_installs SET plays = plays + 1, last_play = ? WHERE id = ?' : 'UPDATE launcher_installs SET opens = opens + 1, last_seen = ? WHERE id = ?').bind(n, id),
    db.prepare('INSERT OR IGNORE INTO stats_seen (day, kind, id) VALUES (?, ?, ?)').bind(day, play ? 'lp' : 'lo', id)
  ]);
  return trackOk();
}

async function getWebStats({ request, env, url }) {
  await requireAdmin(request, env);
  const db = env.DB, days = Math.max(7, Math.min(365, parseInt(url.searchParams.get('days'), 10) || 30));
  const from = isoAgo((days - 1) * 864e5).slice(0, 10), fromIso = from + 'T00:00:00';
  const one = (sql, ...a) => db.prepare(sql).bind(...a).first();
  const perDay = (kind) => all(db.prepare('SELECT day, COUNT(*) AS n FROM stats_seen WHERE kind = ? AND day >= ? GROUP BY day').bind(kind, from));
  const [people, newPeople, pv, dlAll, dlRange, v, lo, lp, li, top, refs, countries, devices, inst, inst7, inst30, versions, plays, todayV] = await Promise.all([
    one('SELECT COUNT(*) AS n FROM stats_visitors'),
    one('SELECT COUNT(*) AS n FROM stats_visitors WHERE first_seen >= ?', fromIso),
    one('SELECT COALESCE(SUM(views), 0) AS n FROM stats_pages WHERE day >= ?', from),
    one('SELECT COUNT(*) AS n FROM stats_visitors WHERE downloaded IS NOT NULL'),
    one('SELECT COUNT(*) AS n FROM stats_visitors WHERE downloaded >= ?', fromIso),
    perDay('v'), perDay('lo'), perDay('lp'),
    all(db.prepare('SELECT substr(first_seen, 1, 10) AS day, COUNT(*) AS n FROM launcher_installs WHERE first_seen >= ? GROUP BY day').bind(fromIso)),
    all(db.prepare('SELECT path, SUM(views) AS views, SUM(people) AS people FROM stats_pages WHERE day >= ? GROUP BY path ORDER BY people DESC, views DESC LIMIT 10').bind(from)),
    all(db.prepare("SELECT COALESCE(ref, '') AS k, COUNT(*) AS n FROM stats_visitors WHERE first_seen >= ? GROUP BY k ORDER BY n DESC LIMIT 8").bind(fromIso)),
    all(db.prepare("SELECT COALESCE(country, '') AS k, COUNT(*) AS n FROM stats_visitors WHERE last_seen >= ? GROUP BY k ORDER BY n DESC LIMIT 8").bind(fromIso)),
    all(db.prepare("SELECT COALESCE(device, 'PC') AS k, COUNT(*) AS n FROM stats_visitors WHERE last_seen >= ? GROUP BY k ORDER BY n DESC").bind(fromIso)),
    one('SELECT COUNT(*) AS n FROM launcher_installs'),
    one('SELECT COUNT(*) AS n FROM launcher_installs WHERE last_seen >= ?', isoAgo(7 * 864e5)),
    one('SELECT COUNT(*) AS n FROM launcher_installs WHERE last_seen >= ?', isoAgo(30 * 864e5)),
    all(db.prepare("SELECT COALESCE(version, '?') AS k, COUNT(*) AS n FROM launcher_installs WHERE last_seen >= ? GROUP BY k ORDER BY n DESC LIMIT 8").bind(isoAgo(30 * 864e5))),
    one('SELECT COUNT(*) AS n FROM launcher_installs WHERE plays > 0'),
    one("SELECT COUNT(*) AS n FROM stats_seen WHERE kind = 'v' AND day = ?", now().slice(0, 10))
  ]);
  const series = [];
  const map = (rows) => Object.fromEntries(rows.map((r) => [r.day, r.n]));
  const mv = map(v), mlo = map(lo), mlp = map(lp), mli = map(li);
  for (let i = days - 1; i >= 0; i--) { const d = isoAgo(i * 864e5).slice(0, 10); series.push({ day: d, visitors: mv[d] || 0, launcher: mlo[d] || 0, plays: mlp[d] || 0, installs: mli[d] || 0 }); }
  return json({
    days, series,
    web: { people: people.n, newPeople: newPeople.n, today: todayV.n, views: pv.n, downloads: dlAll.n, downloadsRange: dlRange.n, top, refs, countries, devices },
    launcher: { installs: inst.n, active7: inst7.n, active30: inst30.n, played: plays.n, versions }
  });
}

const ROUTES = [
  ['GET', 'config', getConfig],
  ['POST', 'apply', postApply],
  ['GET', 'status', getStatus],
  ['GET', 'setup', getSetup],
  ['POST', 'setup', postSetup],
  ['POST', 'admin/login', postLogin],
  ['POST', 'admin/logout', postLogout],
  ['GET', 'admin/me', getMe],
  ['GET', 'admin/applications', listApplications],
  ['GET', 'admin/applications/:id', getApplication],
  ['POST', 'admin/applications/:id/status', setStatus],
  ['POST', 'admin/applications/:id/notes', addNote],
  ['DELETE', 'admin/applications/:id', deleteApplication],
  ['GET', 'admin/team', getTeam],
  ['POST', 'admin/team', createTeam],
  ['POST', 'admin/team/:id', updateTeam],
  ['POST', 'admin/password', changePassword],
  ['PUT', 'admin/settings', saveSettings],
  ['GET', 'news', getPublicNews],
  ['POST', 'server/sync', serverSync],
  ['POST', 'server/heartbeat', serverHeartbeat],
  ['GET', 'server/bancheck', serverBanCheck],
  ['POST', 'server/sanction', serverSanction],
  ['POST', 'server/coords', serverCoords],
  ['POST', 'server/log', serverLog],
  ['GET', 'server/commands', serverCommands],
  ['POST', 'server/maintenance', serverMaintenance],
  ['POST', 'server/logs', serverLogs],
  ['POST', 'server/report', serverReport],
  ['POST', 'server/report/:id', serverReportUpdate],
  ['GET', 'server/reports', serverReports],
  ['GET', 'server/player', serverPlayerFile],
  ['GET', 'server/bans', serverBans],
  ['POST', 'server/unban', serverUnban],
  ['POST', 'admin/server/report/:id', setReportPanel],
  ['GET', 'admin/server', getServerAdmin],
  ['POST', 'admin/server/key', createServerKey],
  ['POST', 'admin/server/command', sendServerCommand],
  ['POST', 'admin/server/import', importResources],
  ['POST', 'admin/dev/coords', addCoordPanel],
  ['DELETE', 'admin/dev/coords/:id', deleteCoord],
  ['GET', 'socials', getPublicSocials],
  ['GET', 'admin/socials', getSocialsAdmin],
  ['PUT', 'admin/socials', saveSocials],
  ['GET', 'rules', getPublicRules],
  ['GET', 'admin/rules', getRulesAdmin],
  ['GET', 'admin/webhooks', getWebhooks],
  ['PUT', 'admin/webhooks/rules', (c) => saveWebhook({ ...c, params: { kind: 'rules' } })],
  ['POST', 'admin/webhooks/rules/test', (c) => testWebhook({ ...c, params: { kind: 'rules' } })],
  ['GET', 'admin/rules/versions/:id', getRulesVersion],
  ['POST', 'admin/rules', saveRules],
  ['GET', 'roadmap', getPublicRoadmap],
  ['GET', 'admin/teamlist', getTeamList],
  ['GET', 'admin/teamlist/:id', getTeamMember],
  ['PUT', 'admin/teamlist/:id', saveTeamProfile],
  ['POST', 'admin/teamlist/:id/records', addTeamRecord],
  ['DELETE', 'admin/teamrecords/:id', deleteTeamRecord],
  ['GET', 'admin/teamwarns', listTeamWarns],
  ['POST', 'track', postTrack],
  ['POST', 'track/launcher', postTrackLauncher],
  ['GET', 'admin/webstats', getWebStats],
  ['POST', 'admin/teamwarns', createTeamWarn],
  ['POST', 'admin/teamwarns/:id/lift', liftTeamWarn],
  ['POST', 'admin/teamwarns/:id/ack', ackTeamWarn],
  ['GET', 'admin/events', listEvents],
  ['POST', 'admin/events', createEvent],
  ['PUT', 'admin/events/:id', updateEvent],
  ['DELETE', 'admin/events/:id', deleteEvent],
  ['POST', 'admin/events/:id/rsvp', rsvpEvent],
  ['POST', 'admin/absences', createAbsence],
  ['DELETE', 'admin/absences/:id', deleteAbsence],
  ['GET', 'admin/polls', listPolls],
  ['POST', 'admin/polls', createPoll],
  ['POST', 'admin/polls/:id/vote', votePoll],
  ['POST', 'admin/polls/:id/close', closePoll],
  ['DELETE', 'admin/polls/:id', deletePoll],
  ['GET', 'admin/snippets', listSnippets],
  ['POST', 'admin/snippets', createSnippet],
  ['PUT', 'admin/snippets/:id', updateSnippet],
  ['POST', 'admin/snippets/:id/use', useSnippet],
  ['DELETE', 'admin/snippets/:id', deleteSnippet],
  ['GET', 'admin/stats', getStats],
  ['GET', 'launcher', getPublicLauncher],
  ['GET', 'launcher/ban', launcherBanCheck],
  ['GET', 'admin/launcher', getLauncherAdmin],
  ['PUT', 'admin/launcher', saveLauncher],
  ['GET', 'admin/pulse', getPulse],
  ['GET', 'admin/search', getSearch],
  ['GET', 'admin/dashboard', getDashboard],
  ['GET', 'admin/activity', getActivity],
  ['POST', 'admin/announcements', createAnnouncement],
  ['PUT', 'admin/announcements/:id', updateAnnouncement],
  ['DELETE', 'admin/announcements/:id', deleteAnnouncement],
  ['GET', 'admin/players', listPlayers],
  ['POST', 'admin/players', createPlayer],
  ['GET', 'admin/players/:id', getPlayer],
  ['PUT', 'admin/players/:id', updatePlayer],
  ['DELETE', 'admin/players/:id', deletePlayer],
  ['POST', 'admin/players/:id/sanctions', addSanction],
  ['POST', 'admin/sanctions/:id/lift', liftSanction],
  ['DELETE', 'admin/sanctions/:id', deleteSanction],
  ['GET', 'admin/news', listNews],
  ['POST', 'admin/news', createNews],
  ['PUT', 'admin/news/:id', updateNews],
  ['DELETE', 'admin/news/:id', deleteNews],
  ['GET', 'admin/dev', getDev],
  ['POST', 'admin/dev/tasks', createTask],
  ['GET', 'admin/dev/tasks/:id', getTask],
  ['PUT', 'admin/dev/tasks/:id', updateTask],
  ['DELETE', 'admin/dev/tasks/:id', deleteTask],
  ['POST', 'admin/dev/tasks/:id/comments', addComment],
  ['POST', 'admin/dev/tasks/:id/checks', addCheck],
  ['PUT', 'admin/dev/checks/:id', updateCheck],
  ['DELETE', 'admin/dev/checks/:id', deleteCheck],
  ['POST', 'admin/dev/milestones', createMilestone],
  ['PUT', 'admin/dev/milestones/:id', updateMilestone],
  ['DELETE', 'admin/dev/milestones/:id', deleteMilestone],
  ['GET', 'admin/dev/resources', listResources],
  ['POST', 'admin/dev/resources', createResource],
  ['PUT', 'admin/dev/resources/:id', updateResource],
  ['DELETE', 'admin/dev/resources/:id', deleteResource],
  ['GET', 'admin/dev/docs', listDocs],
  ['POST', 'admin/dev/docs', createDoc],
  ['PUT', 'admin/dev/docs/:id', updateDoc],
  ['DELETE', 'admin/dev/docs/:id', deleteDoc],
  ['GET', 'admin/plan', listPlan],
  ['POST', 'admin/plan', createPlan],
  ['GET', 'admin/plan/:id', getPlanItem],
  ['PUT', 'admin/plan/:id', updatePlan],
  ['DELETE', 'admin/plan/:id', deletePlan]
];

function match(pattern, path) {
  const p = pattern.split('/'), s = path.split('/');
  if (p.length !== s.length) return null;
  const params = {};
  for (let i = 0; i < p.length; i++) {
    if (p[i].startsWith(':')) { if (!/^\d+$/.test(s[i])) return null; params[p[i].slice(1)] = s[i]; }
    else if (p[i] !== s[i]) return null;
  }
  return params;
}

export async function onRequest(context) {
  const { request, env } = context;
  const url = new URL(request.url);
  const path = url.pathname.replace(/^\/api\/?/, '').replace(/\/$/, '');

  if (!env.DB) return fail('Die Datenbank ist nicht verbunden. Prüfe das D1-Binding „DB“ (siehe Anleitung).', 500);

  // Schutz vor fremden Seiten, die im Namen eines Admins Anfragen schicken
  if (request.method !== 'GET') {
    const origin = request.headers.get('Origin');
    if (origin && new URL(origin).host !== url.host) return fail('Anfrage von fremder Seite abgelehnt.', 403);
    if (!(request.headers.get('Content-Type') || '').includes('application/json') && request.method !== 'DELETE') return fail('Ungültige Anfrage.', 415);
  }

  for (const [method, pattern, handler] of ROUTES) {
    const params = match(pattern, path);
    if (!params) continue;
    if (request.method !== method) continue;
    try {
      return await handler({ request, env, url, params, ctx: context });
    } catch (e) {
      if (e instanceof HttpError) return fail(e.message, e.status);
      console.error(e);
      return fail('Da ist etwas schiefgelaufen. Versuch es gleich nochmal.', 500);
    }
  }
  return fail('Nicht gefunden.', 404);
}
